package com.infra.digital.service;

import java.io.IOException;
import java.util.HashMap;

import com.infra.digital.req.bean.CustomerFaceDetectDTO;
import com.infra.digital.req.bean.CustomerPaymentDTO;
import com.infra.digital.req.bean.CustomerRegReqDTO;
import com.infra.digital.req.bean.CustomerVerificationReqDTO;

public interface ICustomerCoreService {

	boolean validateClient(HashMap<String,String> verifyClientDataMap);

	String registerCustomer(CustomerRegReqDTO req) throws IOException;

	String generateErrResponse(String unauthClientMsg);

	String verifyCustomer(CustomerVerificationReqDTO req);

	String validateCustomer(CustomerRegReqDTO req);

	String fetchFundDetails(CustomerRegReqDTO req);

	String extractFace(CustomerVerificationReqDTO req);

	String validateTrxnAmt(CustomerPaymentDTO req);

	String detectBlink(HashMap<String, String> blinkDetectParamsMap);

	void deleteBlinkVideo(HashMap<String, String> blinkDetectParamsMap);

}
