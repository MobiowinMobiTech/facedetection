package com.infra.digital.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.infra.digital.bean.CustomerRegBean;
import com.mongodb.client.result.UpdateResult;

public class CustomCustomerRepositoryImpl implements CustomCustomerRepository {

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public int updateActiveCustomerFlag(String customerId, String delFlag) {
		Query query = new Query(Criteria.where("customerId").is(customerId));
		Update update = new Update();
		update.set("delFlag", delFlag);

		UpdateResult result = mongoTemplate.updateFirst(query, update, CustomerRegBean.class);

		if (result != null)
			return (int) result.getModifiedCount();
		else
			return 0;

	}

}
