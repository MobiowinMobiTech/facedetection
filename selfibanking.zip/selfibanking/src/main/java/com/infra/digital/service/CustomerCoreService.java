package com.infra.digital.service;

import static org.hamcrest.CoreMatchers.is;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import com.infra.digital.bean.ClientRegBean;
import com.infra.digital.bean.CustomerFaceDetectionBean;
import com.infra.digital.bean.CustomerRegBean;
import com.infra.digital.bean.CustomerVerificationBean;
import com.infra.digital.bean.ResponseBean;
import com.infra.digital.commons.ApplicationConstants;
import com.infra.digital.helper.CustomerHelperService;
import com.infra.digital.helper.CustomerImgVerifyService;
import com.infra.digital.helper.ImageHelperService;
import com.infra.digital.repository.ClientRepository;
import com.infra.digital.repository.CustomerRepository;
import com.infra.digital.req.bean.CustomerPaymentDTO;
import com.infra.digital.req.bean.CustomerRegReqDTO;
import com.infra.digital.req.bean.CustomerVerificationReqDTO;
import com.infra.digital.util.ApplicationUtility;
import com.infra.digital.util.IdGenratorUtility;
import com.infra.digital.util.VedioForamtConvertionUtil;

@Component
public class CustomerCoreService implements ICustomerCoreService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ClientRepository clientRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private ImageHelperService imageHelperService;

	@Autowired
	private CustomerHelperService customerHelperService;

	@Autowired
	private CustomerImgVerifyService customerImgVerificationService;

	@Override
	public boolean validateClient(HashMap<String, String> reqDataMap) {
		log.info("Inside CustomerCoreService/validateClient()");

		List<ClientRegBean> clientRegList = clientRepository.findByApiKeyAndDelFlag(
				reqDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.API_KEY),
				ApplicationConstants.APP_VALUE_CONSTANTS.DEL_FLAG_INACTIVE);

		log.info("Client reg list is : " + clientRegList.size());

		if (clientRegList.size() > 0 && clientRegList.size() < 2)
			return true;
		return false;
	}

	@Override
	public String validateCustomer(CustomerRegReqDTO req) {

		log.info("Inside CustomerCoreService/validateCustomer()");

		CustomerRegBean customerRegBean = null;
		HashMap<String, Object> responseMap = null;
		HashMap<String, String> responseDataMap = null;
		List<CustomerRegBean> custRegList = null;

		try {
			if (null != req) {
				customerRegBean = new CustomerRegBean();

				customerRegBean.setClientId(req.getClientId());
				customerRegBean.setMobileNo(req.getCustData().getMobileNo());
				customerRegBean.setmPin(req.getCustData().getmPin());
				customerRegBean.setDeviceId(req.getCustData().getDeviceId());
				customerRegBean.setDelFlag(ApplicationConstants.APP_VALUE_CONSTANTS.DEL_FLAG_INACTIVE);

				log.info("Customer login req is : " + customerRegBean);

				custRegList = customerRepository.findByClientIdAndMobileNoAndDeviceIdAndDelFlag(
						customerRegBean.getClientId(), customerRegBean.getMobileNo(), customerRegBean.getDeviceId(),
						customerRegBean.getDelFlag());

				log.info("Customer validation list is : " + custRegList);

				if (null != custRegList && (custRegList.size() > 0 && custRegList.size() < 2)) {

					if (customerRegBean.getmPin().equals(custRegList.get(0).getmPin())) {
						responseMap = new HashMap<String, Object>();
						responseMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID,
								custRegList.get(0).getCustomerId());

						return ApplicationUtility.createSuccessMessage(responseMap,
								ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_LOGIN);
					} else {
						return ApplicationUtility.createErrorMessage(
								ApplicationConstants.APP_MESSAGES.INVALID_CREDENTIALS,
								ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_LOGIN);
					}

				} else {
					return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.USER_NOT_FOUND,
							ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_LOGIN);
				}

			}
		} catch (Exception ex) {
			ex.printStackTrace();
			log.error("Exception in saving customer data : " + ex.getMessage(), ex.getCause());
		}

		return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
				ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_LOGIN);
	}

	@Override
	public String validateTrxnAmt(CustomerPaymentDTO req) {
		log.info("Inside CustomerCoreService/validateTrxnAmt()");

		CustomerRegBean customerRegBean = null;
		List<CustomerRegBean> custRegList = null;

		try {

			log.info("Req is : " + req);

			if (null != req) {
				customerRegBean = new CustomerRegBean();
				customerRegBean.setClientId(req.getClientId());
				customerRegBean.setCustomerId(req.getCustData().getCustId());
				customerRegBean.setTransactionLimit(Double.valueOf(req.getCustData().getTransLimit()));

				custRegList = customerRepository.findByClientIdAndCustomerId(customerRegBean.getClientId(),
						customerRegBean.getCustomerId());
				
				log.info("custRegList:  " + custRegList.size());

				// log.info("custRegList.get(0).getTransactionLimit() : " +
				// custRegList.get(0).getTransactionLimit());
				// log.info("Double.valueOf(req.getCustData().getTransLimit() : " +
				// Double.valueOf(req.getCustData().getTransLimit()));

				if (null != custRegList && custRegList.size() > 0) {

					log.info("custRegList.get(0).getTransactionLimit() : " + custRegList.get(0).getTransactionLimit());
					log.info("Double.valueOf(req.getCustData().getTransLimit() : "
							+ Double.valueOf(req.getCustData().getTransLimit()));

					if (Double.valueOf(req.getCustData().getTransLimit()) >= custRegList.get(0).getTransactionLimit()) {

						return ApplicationUtility.createSuccessMessage(
								ApplicationConstants.APP_MESSAGES.GENERIC_SUCCESS_MSG,
								ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_VALIDATE_TRXN);
					}

					return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_FAILURE_MSG,
							ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_VALIDATE_TRXN);

				}

			}
		} catch (Exception e) {

			log.error("Exception in validate transaction amount : " + e.getMessage(), e.getCause());
			e.printStackTrace();
			return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_FAILURE_MSG,
					ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_VALIDATE_TRXN);
		}

		return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_FAILURE_MSG,
				ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_VALIDATE_TRXN);

	}

	@Override
	public String registerCustomer(CustomerRegReqDTO req) {
		log.info("Inside CustomerCoreService/registerCustomer()");

		CustomerRegBean customerRegBean = null;
		HashMap<String, Object> responseMap = null;
		HashMap<String, String> responseDataMap = null;
		List<CustomerRegBean> custRegList = null;
		List<String> imgUrlList = null;
		List<CustomerRegBean> custActiveRegList = null;

		try {
			if (null != req) {
				customerRegBean = new CustomerRegBean();
				customerRegBean.setId(IdGenratorUtility.generateCustomerId(req));
				customerRegBean.setClientId(req.getClientId());
				customerRegBean.setMobileNo(req.getCustData().getMobileNo());
				customerRegBean.setmPin(req.getCustData().getmPin());
				customerRegBean.setCustomerId(req.getCustData().getCustId());
				customerRegBean.setTransactionLimit(Double.valueOf(req.getCustData().getTransLimit()));
				customerRegBean.setName(req.getCustData().getName());
				customerRegBean.setCustImg1(req.getCustData().getImg1());
				// customerRegBean.setCustImg2(req.getCustData().getImg2());
				// customerRegBean.setLongitute(Long.valueOf(req.getCustData().getLongitute()));
				// customerRegBean.setLatitude(Long.valueOf(req.getCustData().getLat()));
				customerRegBean.setCurrency(req.getCustData().getCurrency());
				customerRegBean.setDeviceId(req.getCustData().getDeviceId());
				customerRegBean.setDelFlag(ApplicationConstants.APP_VALUE_CONSTANTS.DEL_FLAG_INACTIVE);

				log.info("customerRegBean is : " + customerRegBean);

				custRegList = customerRepository.findByClientIdAndMobileNoAndDeviceIdAndDelFlag(
						customerRegBean.getClientId(), customerRegBean.getMobileNo(), customerRegBean.getDeviceId(),
						customerRegBean.getDelFlag());

				log.info("custRegList size is : " + custRegList.size());

				if (null != custRegList && custRegList.size() == 0) {
					custActiveRegList = customerRepository.findByClientIdAndMobileNo(customerRegBean.getClientId(),
							customerRegBean.getMobileNo());

					if (null != custActiveRegList && custActiveRegList.size() > 0) {
						customerRegBean.setCustomerId(custActiveRegList.get(0).getCustomerId());
						customerRepository.updateActiveCustomerFlag(customerRegBean.getCustomerId(),
								ApplicationConstants.APP_VALUE_CONSTANTS.DEL_FLAG_ACTIVE);
					}

					imgUrlList = imageHelperService.saveCustomerImage(customerRegBean);

					if (null != imgUrlList) {
						responseDataMap = new HashMap<String, String>();
						customerRegBean.setCustImg1(imgUrlList.get(0));
						// customerRegBean.setCustImg2(imgUrlList.get(1));

						customerRepository.save(customerRegBean);

						responseDataMap.put("img1", customerRegBean.getCustImg1());

						responseMap = new HashMap<String, Object>();
						responseMap.put(ApplicationConstants.APP_KEY_CONSTANTS.IMAGE_ASSIGNER, responseDataMap);
						responseMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID,
								customerRegBean.getCustomerId());

						return ApplicationUtility.createSuccessMessage(responseMap,
								ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_REGISTRATION);
					} else {
						return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
								ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_REGISTRATION);
					}
				} else {
					return ApplicationUtility.createErrorMessage(
							ApplicationConstants.APP_MESSAGES.ALREADY_REGISTERED_MSG,
							ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_REGISTRATION);
				}

			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
			log.error("Exception in saving customer number data  : " + e.getMessage(), e.getCause());
		} catch (Exception ex) {
			ex.printStackTrace();
			log.error("Exception in saving customer data : " + ex.getMessage(), ex.getCause());
		}

		return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
				ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_REGISTRATION);
	}

	@Override
	public String generateErrResponse(String msg) {

		return ApplicationUtility.createErrorMessage(msg,
				ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
	}

	@Override
	public String verifyCustomer(CustomerVerificationReqDTO req) {
		log.info("Inside CustomerCoreService/verifyCustomer()");

		CustomerVerificationBean customerVerificationBean = null;
		HashMap<String, Object> responseMap = null;
		String customerKnownDataDir = null;
		boolean isCustomerTraningDataPresent = false;
		String imageToBeVerifyPath = null;
		String verifyImgResponse = null;
		HashMap<String, Object> toBeVerifyDataMap = null;
		HashMap<String, String> custImgDataMap = null;
		HashMap<String, Object> faceDetectionMap = null;
		HashMap<String, String> faceDetectionResMap = null;
		String faceExtractionResponse = null;

		log.info("<---------------->" + req.getCustData().getCustImg());

		if (null != req && (null != req.getCustData().getCustImg() && !req.getCustData().getCustImg().isEmpty())) {
			customerVerificationBean = new CustomerVerificationBean();
			customerVerificationBean.setClientId(req.getClientId());
			customerVerificationBean.setCustomerId(req.getCustData().getCustId());
			customerVerificationBean.setName(req.getCustData().getName());
			customerVerificationBean.setTransactionAmt(Double.valueOf(req.getCustData().getTransAmt()));
			customerVerificationBean.setCustImg(req.getCustData().getCustImg());

			customerKnownDataDir = customerHelperService.isCustomerRegister(customerVerificationBean);

			if (null != customerKnownDataDir) {

				log.info("Customer known faces dir : " + customerKnownDataDir);

				isCustomerTraningDataPresent = customerHelperService
						.isCustomerTraningDataPresent(customerVerificationBean);

				if (isCustomerTraningDataPresent) {

					custImgDataMap = new HashMap<String, String>();
					custImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID, req.getClientId());
					custImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID, req.getCustData().getCustId());
					custImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG, req.getCustData().getCustImg());
					custImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.ACTION,
							ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);

					imageToBeVerifyPath = imageHelperService.getCustomerImgFilePath(custImgDataMap);

					log.info("imageToBeVerifyPath : " + imageToBeVerifyPath);

					if (null != imageToBeVerifyPath) {
						log.info("imageToBeVerifyPath : " + imageToBeVerifyPath);

						faceDetectionMap = new HashMap<String, Object>();
						faceDetectionMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_EXTRACT,
								imageToBeVerifyPath);
						faceDetectionMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID,
								custImgDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID));
						faceExtractionResponse = customerImgVerificationService
								.customerFaceExtraction(faceDetectionMap);

						faceDetectionResMap = processFaceDetectionResponse(faceExtractionResponse);

						log.info("faceDetectionResMap : " + faceDetectionResMap);

						if (faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
								.equals(ApplicationConstants.APP_VALUE_CONSTANTS.SUCCESS)) {

							toBeVerifyDataMap = new HashMap<String, Object>();
							toBeVerifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_KNOWN_FACE_DIR,
									customerKnownDataDir);
							toBeVerifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY,
									faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_PATH));

							verifyImgResponse = customerImgVerificationService.customerFaceRekogn(toBeVerifyDataMap);

							if (null != verifyImgResponse) {

								log.info("Face rekognization response : " + verifyImgResponse);

								if (processImageVerificationRes(verifyImgResponse)) {

									toBeVerifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID,
											customerVerificationBean.getClientId());
									toBeVerifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID,
											customerVerificationBean.getCustomerId());
									try {
										imageHelperService.addImageIntoTraningData(toBeVerifyDataMap);
									} catch (IOException e) {
										log.error("IOException in adding image to customer traning data : "
												+ e.getMessage(), e.getCause());
										e.printStackTrace();
									}

									return ApplicationUtility.createSuccessMessage(
											ApplicationConstants.APP_MESSAGES.FACE_RECOG_SUCCESS_MSG,
											ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
								} else {
									return ApplicationUtility.createErrorMessage(
											ApplicationConstants.APP_MESSAGES.FACE_RECOG_ERR_MSG,
											ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
								}

							}

						}

						if (faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
								.equals(ApplicationConstants.FACE_DETECTION_MESSAGES_CODES.MULTIPLE_FACE_FOUND)) {
							return ApplicationUtility.createErrorMessage(
									ApplicationConstants.APP_MESSAGES.MULTIPLE_FACE_FOUND,
									ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
						}

					}
				} else {
					return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.NO_TRAINING_DATA_MSG,
							ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
				}
			} else {
				return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.NO_TRAINING_DIR_MSG,
						ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
			}

		}
		return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
				ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
	}

	@Override
	public String extractFace(CustomerVerificationReqDTO req) {

		log.info("inside CustomerCoreService/extractFace()");

		CustomerFaceDetectionBean customerFaceDetectionBean = null;
		HashMap<String, String> custImgDataMap = null;
		String imageToBeVerifyPath = null;
		String faceExtractionResponse = null;
		HashMap<String, Object> faceDetectionMap = null;
		HashMap<String, String> faceDetectionResMap = null;
		HashMap<String, Object> responseMap = null;

		if (null != req && (null != req.getCustData().getCustImg() && !req.getCustData().getCustImg().isEmpty())) {
			customerFaceDetectionBean = new CustomerFaceDetectionBean();
			custImgDataMap = new HashMap<String, String>();

			custImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID, req.getClientId());
			custImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID, req.getCustData().getCustId());
			custImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG, req.getCustData().getCustImg());
			custImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.ACTION,
					ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_FACE_EXTRACTION);

			imageToBeVerifyPath = imageHelperService.getCustomerImgFilePath(custImgDataMap);

			if (null != imageToBeVerifyPath) {
				faceDetectionMap = new HashMap<String, Object>();
				faceDetectionMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_EXTRACT,
						imageToBeVerifyPath);
				faceDetectionMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID,
						custImgDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID));
				faceExtractionResponse = customerImgVerificationService.customerFaceExtraction(faceDetectionMap);

				if (null != faceExtractionResponse) {

					log.info("Face detection response : " + faceExtractionResponse);

					faceDetectionResMap = processFaceDetectionResponse(faceExtractionResponse);

					log.info("faceDetectionResMap : " + faceDetectionResMap);

					if (null != faceDetectionResMap) {
						if (faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
								.equals(ApplicationConstants.APP_VALUE_CONSTANTS.SUCCESS)) {

							String imgPath = faceDetectionResMap
									.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_PATH);

							String encodeBase64img = getBase64EncodedImg(imgPath);

							if (null != encodeBase64img) {
								responseMap = new HashMap<String, Object>();
								responseMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG, encodeBase64img);
							}

							return ApplicationUtility.createSuccessMessage(responseMap,
									ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_FACE_EXTRACTION);

						}

						if (faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
								.equals(ApplicationConstants.FACE_DETECTION_MESSAGES_CODES.NO_FCAE_FOUND)) {

							return ApplicationUtility.createErrorMessage(
									faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE),
									ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_FACE_EXTRACTION);

						}

						if (faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
								.equals(ApplicationConstants.FACE_DETECTION_MESSAGES_CODES.MULTIPLE_FACE_FOUND)) {

							return ApplicationUtility.createErrorMessage(
									faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE),
									ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_FACE_EXTRACTION);

						}
					}

					return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
							ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_FACE_EXTRACTION);

				}

				return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
						ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_FACE_EXTRACTION);
			}

			return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
					ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_FACE_EXTRACTION);
		}

		return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
				ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_FACE_EXTRACTION);
	}

	private String getBase64EncodedImg(String imgPath) {

		String encodedImageString = null;
		FileInputStream fis = null;

		try {
			File f = new File(imgPath);
			fis = new FileInputStream(f);
			byte byteArray[] = new byte[(int) f.length()];
			fis.read(byteArray);
			encodedImageString = Base64.getEncoder().encodeToString(byteArray);

		} catch (Exception ex) {
			log.error("Exception in enoding image : " + ex.getMessage(), ex.getCause());
			ex.printStackTrace();

		} finally {

			if (null != fis) {
				try {
					fis.close();
				} catch (IOException ex) {
					log.error("Exception in closing filestream : " + ex.getMessage(), ex.getCause());
					ex.printStackTrace();
				}
			}

		}

		return encodedImageString;

	}

	private HashMap<String, String> processFaceDetectionResponse(String faceExtractionResponse) {
		log.info("inside CustomerCoreService/processFaceDetectionResponse()");

		HashMap<String, String> resMap = null;
		JSONObject responseJson = null;

		if (null != faceExtractionResponse) {
			resMap = new HashMap<String, String>();
			responseJson = new JSONObject(faceExtractionResponse);

			resMap.put(ApplicationConstants.APP_KEY_CONSTANTS.STATUS,
					responseJson.getString(ApplicationConstants.APP_KEY_CONSTANTS.STATUS));

			resMap.put(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE,
					responseJson.getString(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE));

			if (responseJson.getString(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
					.equals(ApplicationConstants.FACE_DETECTION_MESSAGES_CODES.FACE_FOUND)) {

				resMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_PATH,
						responseJson.getJSONObject(ApplicationConstants.APP_KEY_CONSTANTS.DATA)
								.getString(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_PATH));
			}

			return resMap;

		}

		return resMap;
	}

	private boolean processImageVerificationRes(String verifyImgResponse) {
		log.info("inside CustomerCoreService/processImageVerificationRes()");

		List<ResponseBean> faceRekogResList = null;
		ResponseBean responseBean = null;
		HashMap<Boolean, Float> resMap = null;
		boolean isMatchFound = false;
		try {
			JSONObject responseJson = new JSONObject(verifyImgResponse);
			JSONArray array = (JSONArray) responseJson.get(ApplicationConstants.APP_KEY_CONSTANTS.RESPONSE);

			log.info("array is : " + array);

			if (array.length() > 0) {
				faceRekogResList = new ArrayList<ResponseBean>();
				for (int i = 0; i < array.length(); i++) {

					if (Boolean
							.valueOf(array.getJSONObject(i).getBoolean(ApplicationConstants.APP_KEY_CONSTANTS.IS_MATCH))
							.booleanValue()) {

						responseBean = new ResponseBean();
						responseBean.setDistance(BigDecimal
								.valueOf(array.getJSONObject(i)
										.getDouble(ApplicationConstants.APP_KEY_CONSTANTS.IMAGE_DISTANCE))
								.doubleValue());
						responseBean
								.setIsmatch(Boolean
										.valueOf(array.getJSONObject(i)
												.getBoolean(ApplicationConstants.APP_KEY_CONSTANTS.IS_MATCH))
										.booleanValue());

						faceRekogResList.add(responseBean);

					}
				}

				log.info("faceRekogResList is : " + faceRekogResList.size());

				if (faceRekogResList.size() >= 1)
					return true;
				else
					return false;
			}

		} catch (JSONException e) {
			e.printStackTrace();
			log.error("Exception in resposne parsing : " + e.getMessage(), e.getCause());
		}

		return isMatchFound;

	}

	@Override
	public String fetchFundDetails(CustomerRegReqDTO req) {

		HashMap<String, Object> responseMap = null;

		HashMap<String, String> toResponseDataMap1 = null;
		HashMap<String, String> toResponseDataMap2 = null;
		HashMap<String, String> toResponseDataMap3 = null;

		HashMap<String, String> fromResponseDataMap1 = null;
		HashMap<String, String> fromResponseDataMap2 = null;
		HashMap<String, String> fromResponseDataMap3 = null;

		List<HashMap<String, String>> toAccDataList = null;
		List<HashMap<String, String>> fromAccDataList = null;

		if (null != req) {
			toAccDataList = new ArrayList<HashMap<String, String>>();

			toResponseDataMap1 = new HashMap<String, String>();
			toResponseDataMap1.put("accnum", "12365474154");
			toResponseDataMap1.put("balance", "8200025");
			toResponseDataMap1.put("currency", "INR");

			toResponseDataMap2 = new HashMap<String, String>();
			toResponseDataMap2.put("accnum", "12365474155");
			toResponseDataMap2.put("balance", "1254885");
			toResponseDataMap2.put("currency", "INR");

			toResponseDataMap3 = new HashMap<String, String>();
			toResponseDataMap3.put("accnum", "12365474156");
			toResponseDataMap3.put("balance", "822325");
			toResponseDataMap3.put("currency", "INR");

			toAccDataList.add(toResponseDataMap1);
			toAccDataList.add(toResponseDataMap2);
			toAccDataList.add(toResponseDataMap3);

			fromAccDataList = new ArrayList<HashMap<String, String>>();

			fromResponseDataMap1 = new HashMap<String, String>();
			fromResponseDataMap1.put("accnum", "23654741541");
			fromResponseDataMap1.put("balance", "8200025");
			fromResponseDataMap1.put("currency", "INR");

			fromResponseDataMap2 = new HashMap<String, String>();
			fromResponseDataMap2.put("accnum", "23654741551");
			fromResponseDataMap2.put("balance", "1254885");
			fromResponseDataMap2.put("currency", "INR");

			fromResponseDataMap3 = new HashMap<String, String>();
			fromResponseDataMap3.put("accnum", "23654741561");
			fromResponseDataMap3.put("balance", "822325");
			fromResponseDataMap3.put("currency", "INR");

			fromAccDataList.add(fromResponseDataMap1);
			fromAccDataList.add(fromResponseDataMap2);
			fromAccDataList.add(fromResponseDataMap3);

			responseMap = new HashMap<String, Object>();
			responseMap.put("toAccDetails", toAccDataList);
			responseMap.put("fromAccDetails", fromAccDataList);

			return ApplicationUtility.createSuccessMessage(responseMap,
					ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_FUND_DETAILS);
		}
		return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
				ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_FUND_DETAILS);
	}

	@Override
	public String detectBlink(HashMap<String, String> blinkDetectParamsMap) {

		log.info("Inside CustomerCoreService / detectBlink()");

		HashMap<String, String> blinkDetectResMap = null;
		HashMap<String, Object> resposneMap = null;

		boolean isSuccesfull = VedioForamtConvertionUtil.vedioFormaConversion(blinkDetectParamsMap);

		log.info("isSuccessfuil : " + isSuccesfull);

		// deleteBlinkVideo(blinkDetectParamsMap);

		log.info("***************"
				+ blinkDetectParamsMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_UPLOAD_LOCATION)
				+ blinkDetectParamsMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME).substring(0,
						blinkDetectParamsMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME).lastIndexOf("."))
				+ ".avi");

		String aviFilePath = blinkDetectParamsMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_UPLOAD_LOCATION)+ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR
				+ blinkDetectParamsMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME).substring(0,
						blinkDetectParamsMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME).lastIndexOf("."))
				+ ".avi";

		blinkDetectParamsMap.put(ApplicationConstants.APP_KEY_CONSTANTS.AVI_FILE_PATH, aviFilePath);

		String customerBlinkResponse = customerImgVerificationService.customerBlinkDetection(blinkDetectParamsMap);
		if (log.isInfoEnabled()) {
			log.info("Customer Blink Response : " + customerBlinkResponse);
		}

		if (null != customerBlinkResponse) {
			blinkDetectResMap = processBlickDetectResponse(customerBlinkResponse);

			log.info("blinkDetectResMap : " + blinkDetectResMap);

			// deleteBlinkVideo(blinkDetectParamsMap);
			if (null != blinkDetectResMap) {
				resposneMap = new HashMap<String, Object>();
				if (blinkDetectResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
						.equals(ApplicationConstants.APP_VALUE_CONSTANTS.SUCCESS)) {

					resposneMap = new HashMap<String, Object>();

					return ApplicationUtility.createSuccessMessage(resposneMap,
							ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_BLINK_DETECT);

				} else {
					return ApplicationUtility.createErrorMessage(
							blinkDetectResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE),
							ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_BLINK_DETECT);
				}

			} else {
				return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
						ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_BLINK_DETECT);
			}

		} else {
			return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
					ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_BLINK_DETECT);
		}

	}

	@Async
	@Override
	public void deleteBlinkVideo(HashMap<String, String> blinkDetectParamsMap) {
		log.info("Inside CustomerCoreService/deleteBlinkVideo()");

		File blinkVideoFile = null;
		boolean isDeleted = false;
		File orignalFilePath = null;
		log.info("blinkDetectParamsMap : " + blinkDetectParamsMap);
		
		try {

			blinkVideoFile = new File(blinkDetectParamsMap.get(ApplicationConstants.APP_KEY_CONSTANTS.AVI_FILE_PATH));
			//orignalFilePath = new File(blinkDetectParamsMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_PATH));
			
			// blinkVideoFile.deleteOnExit();
			FileUtils.forceDelete(blinkVideoFile);
			//FileUtils.forceDelete(orignalFilePath);
			log.info("File : " + orignalFilePath.getName() + "Delete status : " + isDeleted);

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in deleting blink vedio file : " + e.getMessage(), e.getCause());
		}

	}

	private HashMap<String, String> processBlickDetectResponse(String customerBlinkResponse) {
		log.info("Inside CustomerCoreService / processBlickDetectResponse()");

		HashMap<String, String> resMap = null;
		JSONObject responseJson = null;

		log.info("customerBlinkResponse: " + customerBlinkResponse);

		if (null != customerBlinkResponse) {
			resMap = new HashMap<String, String>();
			responseJson = new JSONObject(customerBlinkResponse);

			resMap.put(ApplicationConstants.APP_KEY_CONSTANTS.STATUS,
					responseJson.getString(ApplicationConstants.APP_KEY_CONSTANTS.STATUS));

			resMap.put(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE,
					responseJson.getString(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE));

			return resMap;

		}

		return resMap;

	}

}
