package com.infra.digital.service;

import com.infra.digital.req.bean.ClientRegReqDTO;

public interface IClientCoreService {

	boolean validateClient(ClientRegReqDTO clientRegReq);

	String registerClient(ClientRegReqDTO clientRegReq);

	String generateErrResponse();

}
