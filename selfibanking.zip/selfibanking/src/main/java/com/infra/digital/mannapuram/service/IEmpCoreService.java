package com.infra.digital.mannapuram.service;

import com.infra.digital.mannupuram.dto.ValidateEmpDTO;

public interface IEmpCoreService {

	String validateCustomer(ValidateEmpDTO req);

	String generateErrResponse(String genericErrMsg);

	String verifyCustomer(ValidateEmpDTO req);

}
