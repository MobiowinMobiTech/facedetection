package com.infra.digital.util;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDbsSequenceGenUtil {

	public static Object getNextSequence(String seqName, String mongoDatabase, String collectionName) {
		MongoClient mongoClient = new MongoClient();
		MongoDatabase database = mongoClient.getDatabase(mongoDatabase);
		MongoCollection<Document> countersCollection = database.getCollection(collectionName);

		if (countersCollection.count() == 0) {
			createCountersCollection(countersCollection, seqName);
		}
		Document searchQuery = new Document("_id", seqName);
		Document increase = new Document("seq", 1);
		Document updateQuery = new Document("$inc", increase);
		Document result = countersCollection.findOneAndUpdate(searchQuery, updateQuery);

		mongoClient.close();
		return result.get("seq");
	}

	private static void createCountersCollection(MongoCollection<Document> countersCollection, String seqName) {

		Document document = new Document();
		document.append("_id", seqName);
		document.append("seq", 1);
		countersCollection.insertOne(document);
	}
}
