package com.infra.digital.mannupuram.bean;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "employee_master")
public class Employee implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String id;
	private String clientId;
	private String empId;
	private String name;
	private String mobileNo;
	private String deviceId;
	private String empImg;
	private String createdBy;
	private Date createDt;
	private String updatedBy;
	private Date modifyDt;
	private String delFlag;

	public Employee() {
		super();
	}

	public Employee(String id, String clientId, String empId, String name, String mobileNo, String deviceId,
			String empImg, String createdBy, Date createDt, String updatedBy, Date modifyDt, String delFlag) {
		super();
		this.id = id;
		this.clientId = clientId;
		this.empId = empId;
		this.name = name;
		this.mobileNo = mobileNo;
		this.deviceId = deviceId;
		this.empImg = empImg;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.updatedBy = updatedBy;
		this.modifyDt = modifyDt;
		this.delFlag = delFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getEmpImg() {
		return empImg;
	}

	public void setEmpImg(String empImg) {
		this.empImg = empImg;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", clientId=" + clientId + ", empId=" + empId + ", name=" + name + ", mobileNo="
				+ mobileNo + ", deviceId=" + deviceId + ", empImg=" + empImg + ", createdBy=" + createdBy
				+ ", createDt=" + createDt + ", updatedBy=" + updatedBy + ", modifyDt=" + modifyDt + ", delFlag="
				+ delFlag + "]";
	}

}
