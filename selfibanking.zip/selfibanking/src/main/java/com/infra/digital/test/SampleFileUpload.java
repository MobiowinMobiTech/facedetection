package com.infra.digital.test;

import java.io.File;
import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

public class SampleFileUpload {

	public static void main(String[] args) {
		File file = new File("D:\\INFRA_RND\\120418\\testImg\\deepika.jpg");
		FileBody fileBody = new FileBody(file, ContentType.MULTIPART_FORM_DATA);

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addPart("file", fileBody);
		builder.addTextBody("name", "D:\\INFRA_RND\\120418\\testImg\\");

		HttpEntity entity = builder.build();

		HttpPost request = new HttpPost("http://localhost:5002/facerekog/");
		request.setEntity(entity);

		HttpClient client = HttpClientBuilder.create().build();
		try {
			HttpResponse response = client.execute(request);
			int statusCode = response.getStatusLine().getStatusCode();
			System.out.println("status code is : " + statusCode);
			String responseBody = EntityUtils.toString(response.getEntity());
			System.out.println(responseBody);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}