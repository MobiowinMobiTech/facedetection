package com.infra.digital.util;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infra.digital.commons.ApplicationConstants;

public class ApplicationUtility {

	private static ObjectMapper objectMapper = new ObjectMapper();

	@SuppressWarnings("rawtypes")
	public static String createJSONFromMap(Map dataMap) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			objectMapper.writeValue(baos, dataMap);

			return baos.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String createSuccessMessage(HashMap<String, Object> resMap,String actionName) {

		List<Map<String, Object>> lists = null;
		Map<String, Object> successMap = null;
		try {
			successMap = new HashMap<String, Object>();
			lists = new LinkedList<Map<String, Object>>();
			lists.add(resMap);

			successMap.put(ApplicationConstants.APP_KEY_CONSTANTS.STATUS,
					ApplicationConstants.APP_VALUE_CONSTANTS.SUCCESS);
			successMap.put(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE,
					ApplicationConstants.APP_MESSAGES.GENERIC_SUCCESS_MSG);
			successMap.put(ApplicationConstants.APP_KEY_CONSTANTS.ACTION, actionName);
			successMap.put(ApplicationConstants.APP_KEY_CONSTANTS.DATA, lists);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			objectMapper.writeValue(baos, successMap);

			return baos.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String createErrorMessage(HashMap<String, Object> resMap) {

		List<Map<String, Object>> lists = null;
		Map<String, Object> errMap = null;
		try {
			errMap = new HashMap<String, Object>();
			lists = new LinkedList<Map<String, Object>>();
			lists.add(resMap);

			errMap.put(ApplicationConstants.APP_KEY_CONSTANTS.STATUS, ApplicationConstants.APP_VALUE_CONSTANTS.FAILURE);
			errMap.put(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE,
					ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG);
			errMap.put(ApplicationConstants.APP_KEY_CONSTANTS.DATA, lists);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			objectMapper.writeValue(baos, errMap);

			return baos.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String createErrorMessage(String msg,String actionName) {

		List<Map<String, Object>> lists = null;
		Map<String, Object> errMap = null;
		Map<String, Object> errMsgMap = null;
		try {
			errMap = new HashMap<String, Object>();
			errMsgMap = new HashMap<String, Object>();
			lists = new LinkedList<Map<String, Object>>();
			lists.add(errMsgMap);

			errMap.put(ApplicationConstants.APP_KEY_CONSTANTS.STATUS, ApplicationConstants.APP_VALUE_CONSTANTS.FAILURE);
			errMap.put(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE, msg);
			errMap.put(ApplicationConstants.APP_KEY_CONSTANTS.ACTION, actionName);
			errMap.put(ApplicationConstants.APP_KEY_CONSTANTS.DATA, lists);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			objectMapper.writeValue(baos, errMap);

			return baos.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static String createSuccessMessage(String msg,String actionName) {

		List<Map<String, Object>> lists = null;
		Map<String, Object> successMap = null;
		Map<String, Object> successMsgMap = null;
		try {
			successMap = new HashMap<String, Object>();
			successMsgMap = new HashMap<String, Object>();
			lists = new LinkedList<Map<String, Object>>();
			lists.add(successMsgMap);

			successMap.put(ApplicationConstants.APP_KEY_CONSTANTS.STATUS, ApplicationConstants.APP_VALUE_CONSTANTS.SUCCESS);
			successMap.put(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE, msg);
			successMap.put(ApplicationConstants.APP_KEY_CONSTANTS.ACTION, actionName);
			successMap.put(ApplicationConstants.APP_KEY_CONSTANTS.DATA, lists);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			objectMapper.writeValue(baos, successMap);

			return baos.toString();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/*public String generateErrResponse() {

		HashMap<String, Object> responseMap = null;

		try {
			responseMap = new HashMap<String, Object>();

			return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.DUPLICATE_CLIENT_MSG);

		} catch (Exception e) {
			return ApplicationUtility.createErrorMessage(responseMap);
		}
	}
*/
	public static void main(String[] args) {

		HashMap<String, Object> resMap = new HashMap<String, Object>();
		resMap.put("id", "101431596021671174718");
		resMap.put("name", "Shailendra");

		List<HashMap<String, String>> dataMapList = new ArrayList<HashMap<String, String>>();
		HashMap<String, String> dataMap = new HashMap<String, String>();
		dataMapList.add(dataMap);

		// dataMap.put("", value)
		resMap.put("data", dataMapList);

		System.out.println("<--------------->" + createJSONFromMap(resMap));
	}

}
