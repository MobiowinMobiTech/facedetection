package com.infra.digital.util;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.xml.bind.DatatypeConverter;

import com.infra.digital.bean.ClientRegBean;
import com.infra.digital.commons.ApplicationConstants;
import com.infra.digital.req.bean.ClientRegReqDTO;
import com.infra.digital.req.bean.CustomerRegReqDTO;

public class IdGenratorUtility {

	public static String generateApiKey(ClientRegReqDTO clientRegReq) {
		StringBuilder apiKeybuilder = new StringBuilder();
		apiKeybuilder.append(getSystemNanoTime());
		return apiKeybuilder.toString();

	}

	public static String generateSecKey() throws Exception {
		KeyGenerator generator = KeyGenerator.getInstance(ApplicationConstants.APP_KEY_CONSTANTS.ENCRYPTION_AES);
		generator.init(128); // The AES key size in number of bits
		SecretKey secKey = generator.generateKey();
		return bytesToHex(secKey.getEncoded()).toString();

	}

	private static String bytesToHex(byte[] hash) {
		return DatatypeConverter.printHexBinary(hash);
	}

	public static String getSystemNanoTime() {
		String nanoTime = String.valueOf(System.nanoTime());
		nanoTime = nanoTime.substring(nanoTime.length() - 2, nanoTime.length());
		return nanoTime;
	}

	public static String generateClientId(ClientRegReqDTO clientRegReq) {
		StringBuilder clientIdbuilder = new StringBuilder();
		clientIdbuilder.append(clientRegReq.getMobileNo().substring(clientRegReq.getMobileNo().length() - 4,
				clientRegReq.getMobileNo().length()));
		//clientIdbuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME_SEPERATOR);
		clientIdbuilder.append(getSystemNanoTime());
		return clientIdbuilder.toString();

	}

	public static void main(String[] args) {
	
		ClientRegReqDTO clientRegReq = new ClientRegReqDTO();
		clientRegReq.setMobileNo("8828228072");
		
		String clientId = IdGenratorUtility.generateClientId(clientRegReq);
		
		ClientRegBean clientRegBean = new ClientRegBean();
		
		String s=clientId;  
		int i=Integer.parseInt(s);  
		
		System.out.println("" + i);
		
		//clientRegBean.setId(Integer.parseInt(clientId));
		
		
	}

	public static String generateCustomerId(CustomerRegReqDTO req) {
		StringBuilder customerIdbuilder = new StringBuilder();
		customerIdbuilder.append(req.getClientId());
		customerIdbuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME_SEPERATOR);
		customerIdbuilder.append(req.getCustData().getCustId());
		customerIdbuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME_SEPERATOR);
		customerIdbuilder.append(getSystemNanoTime());
		return customerIdbuilder.toString();
	}
	
}
