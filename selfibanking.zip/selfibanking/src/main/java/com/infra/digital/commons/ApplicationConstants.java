package com.infra.digital.commons;

public interface ApplicationConstants {

	public class APP_KEY_CONSTANTS {
		public static final String NAME = "name";

		public static final String FILE_NAME_SEPERATOR = "_";

		public static final String FILE_EXTENSION_BUILDER = ".";

		public static final String JPG_IMG_EXTENSION = "jpg";

		public static final String ENCRYPTION_AES = "AES";

		public static final String API_KEY = "apiKey";

		public static final String SEC_KEY = "securityKey";

		public static final String CLIENT_ID = "clientId";

		public static final String STATUS = "status";

		public static final String MESSAGE = "message";
		
		public static final String ACTION = "action";
		
		public static final String RESPONSE = "response";

		public static final String DATA = "data";

		public static final String IMG_LIST = "IMG_LIST";

		public static final String CUST_ID = "customerId";

		public static final String TO_BE_CHECK_IMG_NAME = "imgname";

		public static final String IMG_DIR_PATH = "imgToBeCheckPath";

		public static final String CUST_KNOWN_FACE_DIR = "knownfacedir";
		
		public static final String CUST_GREY_FCAE_DIR = "greyfacedir";

		public static final String CUST_IMG_TO_BE_VERIFY = "custimgtobeverify";
		
		public static final String CUST_IMG_TO_BE_EXTRACT = "custimgtobeextract";
		
		public static final String IS_MATCH = "ismatch";
		
		public static final String IMAGE_DISTANCE = "distance";
		
		public static final String URL_APPENDER = "&";

		public static final String VALUE_ASSIGNER = "=";

		//public static final String REQUEST_HEADER = "type";

		public static final String IMAGE_ASSIGNER = "img";
		
		public static final String CUST_IMG = "custimg";
		
		public static final String CUST_IMG_PATH = "imgpath";
		
		public static final String FILE_PATH = "filepath";
		
		public static final String FILE_NAME = "filename";
		
		public static final String AVI_FILE_PATH = "avifilepath";
		
		public static final String FILE_NAME_SPLITTER = "_";
		
		public static final String FILE_PATH_SEPERATOR = "//";
		
		public static final String FILE_UPLOAD_LOCATION = "uploadedFileLocation";

	}

	public class APP_VALUE_CONSTANTS {
		public static final String DEL_FLAG_ACTIVE = "T";

		public static final String DEL_FLAG_INACTIVE = "F";

		public static final String FILE_PATH_SEPERATOR = "\\";

		public static final String SUCCESS = "00";

		public static final String FAILURE = "01";

	}
	
	public class MANNAPURAM_APP_KEY_CONSTANTS {
		
		public static final String EMP_ID = "empId";
		
		public static final String NAME = "name";
		
	}

	public class APP_MESSAGES {
		public static final String DUPLICATE_CLIENT_MSG = "Client already registered. Kindly check with vendor.";

		public static final String UNAUTH_CLIENT_MSG = "Client is not Authrozied. Kindly check with your Vendor";

		public static final String NO_TRAINING_DIR_MSG = "Dear Customer, Kindly register with Selfie Payment first.";

		public static final String NO_TRAINING_DATA_MSG = "Dear Customer, Kindly complete with Selfie Payment first.";

		public static final String FACE_RECOG_SUCCESS_MSG = "Face Match Found";

		public static final String FACE_RECOG_ERR_MSG = "No Face match found, Kindly take selfie again";

		public static final String GENERIC_SUCCESS_MSG = "success";
		
		public static final String GENERIC_FAILURE_MSG = "failure";

		public static final String GENERIC_ERR_MSG = "Somthing went wrong...";
		
		public static final String ALREADY_REGISTERED_MSG = "YOU ARE ALREADT REGISTERED FOR SELFIE BANKING.";
		
		public static final String INVALID_CREDENTIALS = "Invalid Credentials, Try again!!!";
		
		public static final String USER_NOT_FOUND = "User not found,Kindly register !!!";
		
		public static final String MULTIPLE_FACE_FOUND = "Multiple face found !!!";
	}
	
	public class APP_ACTION_CONSTANTS {
		public static final String ACTION_LOGIN = "login";
		
		public static final String ACTION_CUSTOMER_REGISTRATION = "customerregistration";

		public static final String ACTION_FUND_DETAILS = "funddetails";
		
		public static final String ACTION_VERIFICATION =  "verification";
		
		public static final String ACTION_CLIENT_REGISTRATION =  "clientregistration";
		
		public static final String ACTION_CUSTOMER_FACE_EXTRACTION =  "facedetect";
		
		public static final String ACTION_CUSTOMER_VALIDATE_TRXN =  "validatetrxn";
		
		public static final String ACTION_CUSTOMER_BLINK_DETECT =  "blinkdetect";

	}

	public class APP_MESSAGES_CODES {
		public static final String DUPLICATE_CLIENT_MSG_CODE = "11";
	}
	
	public class FACE_DETECTION_MESSAGES_CODES {
		public static final String NO_FCAE_FOUND = "01";
		
		public static final String MULTIPLE_FACE_FOUND = "02";
		
		public static final String FACE_FOUND = "00";
		
		
	}
}
