package com.infra.digital.helper;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.infra.digital.commons.ApplicationConstants;

@Component
@PropertySource("classpath:global.properties")
@ConfigurationProperties
public class CustomerImgVerifyService {

	private Log log = LogFactory.getLog(this.getClass());

	@Value("${faceRekogServerAddress}")
	private String faceRekogServerAddress;

	@Value("${faceDetectionServerAddress}")
	private String faceDetectionServerAddress;

	@Value("${blinkDetectionServerAddress}")
	private String blinkDetectionServerAddress;

	@Value("${greyscaleImgPath}")
	private String greyScaleImgBasePath;
	
	@Value("${aviVideo}")
	private String aviVideo;
	
	@Value("${empTrainningImgDir}")
	private String empTrainningImgDir;
	
	@Value("${empImgDir}")
	private String empImgDir;

	HttpClient client = null;
	HttpResponse response = null;
	int statusCode = 0;
	String responseBody = null;

	public String customerFaceRekogn(HashMap<String, Object> toBeVerifyDataMap) {
		log.info("Inside CustomerImgVerifyService /customerFaceRekogn()");

		if (log.isInfoEnabled()) {
			log.info("Verification data map is : " + toBeVerifyDataMap);
		}

		File file = new File(
				String.valueOf(toBeVerifyDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY)));
		FileBody fileBody = new FileBody(file, ContentType.MULTIPART_FORM_DATA);

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addPart(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY, fileBody);
		builder.addTextBody(ApplicationConstants.APP_KEY_CONSTANTS.CUST_KNOWN_FACE_DIR,
				String.valueOf(toBeVerifyDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_KNOWN_FACE_DIR)));

		HttpEntity entity = builder.build();

		HttpPost request = new HttpPost(faceRekogServerAddress);
		request.setEntity(entity);

		client = HttpClientBuilder.create().build();
		try {
			response = client.execute(request);
			statusCode = response.getStatusLine().getStatusCode();
			log.info("status code is : " + statusCode);
			responseBody = EntityUtils.toString(response.getEntity());

			if (log.isInfoEnabled()) {
				log.info("Status code is : " + statusCode);
				log.info("Face recoknition response is : " + responseBody);
			}

			return responseBody;
		} catch (IOException e) {
			log.error("Exception in file processing " + e.getMessage(), e.getCause());
			e.printStackTrace();
		} catch (Exception ex) {
			log.error("Exception in Face recoknition " + ex.getMessage(), ex.getCause());
			ex.printStackTrace();
		}

		return responseBody;
	}

	public String customerFaceExtraction(HashMap<String, Object> faceDetectionMap) {

		log.info("Inside CustomerImgVerifyService/customerFaceExtraction()");

		if (log.isInfoEnabled()) {
			log.info("Customer face extraction data map is : " + faceDetectionMap);
			log.info("faceDetectionServerAddress : " + faceDetectionServerAddress);
		}

		File file = new File(
				String.valueOf(faceDetectionMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_EXTRACT)));
		FileBody fileBody = new FileBody(file, ContentType.MULTIPART_FORM_DATA);

		log.info("customer id is : "
				+ String.valueOf(faceDetectionMap.get((ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID))));

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addPart(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_EXTRACT, fileBody);
		builder.addTextBody(ApplicationConstants.APP_KEY_CONSTANTS.CUST_GREY_FCAE_DIR, greyScaleImgBasePath);
		builder.addTextBody(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID,
				String.valueOf(faceDetectionMap.get((ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID))));

		HttpEntity entity = builder.build();

		HttpPost request = new HttpPost(faceDetectionServerAddress);
		request.setEntity(entity);

		client = HttpClientBuilder.create().build();
		try {
			response = client.execute(request);
			statusCode = response.getStatusLine().getStatusCode();
			log.info("status code is : " + statusCode);
			responseBody = EntityUtils.toString(response.getEntity());

			if (log.isInfoEnabled()) {
				log.info("Status code is : " + statusCode);
				log.info("Face detection response is : " + responseBody);
			}

			return responseBody;
		} catch (IOException e) {
			log.error("Exception in file processing " + e.getMessage(), e.getCause());
			e.printStackTrace();
		} catch (Exception ex) {
			log.error("Exception in Face recoknition " + ex.getMessage(), ex.getCause());
			ex.printStackTrace();
		}

		return responseBody;
	}

	public String customerBlinkDetection(HashMap<String, String> blinkDetectParamsMap) {
		if (log.isInfoEnabled()) {
			log.info("Customer blink detection map data map is : " + blinkDetectParamsMap);
		}

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addTextBody(ApplicationConstants.APP_KEY_CONSTANTS.FILE_PATH,
				blinkDetectParamsMap.get(ApplicationConstants.APP_KEY_CONSTANTS.AVI_FILE_PATH));
		builder.addTextBody(ApplicationConstants.APP_KEY_CONSTANTS.AVI_FILE_PATH,aviVideo);

		HttpEntity entity = builder.build();

		HttpPost request = new HttpPost(blinkDetectionServerAddress);
		request.setEntity(entity);

		client = HttpClientBuilder.create().build();
		try {
			response = client.execute(request);
			statusCode = response.getStatusLine().getStatusCode();
			log.info("status code is : " + statusCode);
			responseBody = EntityUtils.toString(response.getEntity());

			if (log.isInfoEnabled()) {
				log.info("Status code is : " + statusCode);
				log.info("Face recoknition response is : " + responseBody);
			}

			return responseBody;
		} catch (IOException e) {
			log.error("Exception in file processing " + e.getMessage(), e.getCause());
			e.printStackTrace();
		} catch (Exception ex) {
			log.error("Exception in Face recoknition " + ex.getMessage(), ex.getCause());
			ex.printStackTrace();
		}

		return responseBody;

	}
	
	
	public String empFaceRekogn(HashMap<String, Object> toBeVerifyDataMap) {
		log.info("Inside CustomerImgVerifyService /customerFaceRekogn()");

		if (log.isInfoEnabled()) {
			log.info("Verification data map is : " + toBeVerifyDataMap);
		}

		File file = new File(
				String.valueOf(toBeVerifyDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY)));
		FileBody fileBody = new FileBody(file, ContentType.MULTIPART_FORM_DATA);

		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		builder.addPart(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY, fileBody);
		if(toBeVerifyDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.ACTION).equals(ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_LOGIN))
		{
			builder.addTextBody(ApplicationConstants.APP_KEY_CONSTANTS.CUST_KNOWN_FACE_DIR,empTrainningImgDir);
		}
		if(toBeVerifyDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.ACTION).equals(ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION))
		{
			builder.addTextBody(ApplicationConstants.APP_KEY_CONSTANTS.CUST_KNOWN_FACE_DIR,getImgDirPath(toBeVerifyDataMap));
		}
		

		HttpEntity entity = builder.build();

		HttpPost request = new HttpPost(faceRekogServerAddress);
		request.setEntity(entity);

		client = HttpClientBuilder.create().build();
		try {
			response = client.execute(request);
			statusCode = response.getStatusLine().getStatusCode();
			log.info("status code is : " + statusCode);
			responseBody = EntityUtils.toString(response.getEntity());

			if (log.isInfoEnabled()) {
				log.info("Status code is : " + statusCode);
				log.info("Face recoknition response is : " + responseBody);
			}

			return responseBody;
		} catch (IOException e) {
			log.error("Exception in file processing " + e.getMessage(), e.getCause());
			e.printStackTrace();
		} catch (Exception ex) {
			log.error("Exception in Face recoknition " + ex.getMessage(), ex.getCause());
			ex.printStackTrace();
		}

		return responseBody;
	}

	private String getImgDirPath(HashMap<String, Object> toBeVerifyDataMap) {
		StringBuilder imgDirpath = new StringBuilder();
		imgDirpath.append(empImgDir);
		imgDirpath.append(toBeVerifyDataMap.get(ApplicationConstants.MANNAPURAM_APP_KEY_CONSTANTS.EMP_ID));
		imgDirpath.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		
		log.info("imgDirpath : " + imgDirpath.toString());
		
		return imgDirpath.toString();
	}

}
