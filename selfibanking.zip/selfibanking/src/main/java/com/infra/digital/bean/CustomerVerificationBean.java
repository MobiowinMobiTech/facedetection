package com.infra.digital.bean;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "customer_verification_req_master")
public class CustomerVerificationBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private String id;
	private String clientId;
	private String customerId;
	private String name;
	private Double transactionAmt;
	private String currency;
	private String custImg;
	private String createdBy;
	private Date createDt;
	private String updatedBy;
	private Date modifyDt;
	private String delFlag;

	public CustomerVerificationBean() {
		super();
	}

	public CustomerVerificationBean(String id, String clientId, String customerId, String name, Double transactionAmt,
			String currency, String custImg, String createdBy, Date createDt, String updatedBy, Date modifyDt,
			String delFlag) {
		super();
		this.id = id;
		this.clientId = clientId;
		this.customerId = customerId;
		this.name = name;
		this.transactionAmt = transactionAmt;
		this.currency = currency;
		this.custImg = custImg;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.updatedBy = updatedBy;
		this.modifyDt = modifyDt;
		this.delFlag = delFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getTransactionAmt() {
		return transactionAmt;
	}

	public void setTransactionAmt(Double transactionAmt) {
		this.transactionAmt = transactionAmt;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getCustImg() {
		return custImg;
	}

	public void setCustImg(String custImg) {
		this.custImg = custImg;
	}

	@Override
	public String toString() {
		return "CustomerVerificationBean [id=" + id + ", clientId=" + clientId + ", customerId=" + customerId
				+ ", name=" + name + ", transactionAmt=" + transactionAmt + ", currency=" + currency + ", custImg="
				+ custImg + ", createdBy=" + createdBy + ", createDt=" + createDt + ", updatedBy=" + updatedBy
				+ ", modifyDt=" + modifyDt + ", delFlag=" + delFlag + "]";
	}

}
