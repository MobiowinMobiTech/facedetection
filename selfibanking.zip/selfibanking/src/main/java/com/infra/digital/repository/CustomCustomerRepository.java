package com.infra.digital.repository;

public interface CustomCustomerRepository {

	int updateActiveCustomerFlag(String customerId, String delFlag);
}
