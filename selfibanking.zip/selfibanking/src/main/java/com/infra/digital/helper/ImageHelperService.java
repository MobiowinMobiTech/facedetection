package com.infra.digital.helper;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import com.infra.digital.bean.CustomerRegBean;
import com.infra.digital.bean.CustomerVerificationBean;
import com.infra.digital.commons.ApplicationConstants;
import com.infra.digital.util.IdGenratorUtility;

@Component
@PropertySource("classpath:global.properties")
@ConfigurationProperties
@EnableAsync
public class ImageHelperService {

	private Log log = LogFactory.getLog(this.getClass());

	@Value("${traningImgDir}")
	private String tranningImgDir;

	@Value("${customerReqImgDir}")
	private String customerReqImgDir;

	@Value("${faceRekogImgBaseUrl}")
	private String faceRekogImgBaseUrl;
	
	
	
	public List<String> saveCustomerImage(CustomerRegBean customerRegBean) {

		log.info("Tranning dir : " + tranningImgDir);

		List<String> custSelfieDataList = null;

		HashMap<String, Object> customerDetailMap = null;
		
		List<String> imgUrlList = null;
		
		
		try {

			custSelfieDataList = new ArrayList<String>();

			custSelfieDataList.add(customerRegBean.getCustImg1());
			//custSelfieDataList.add(customerRegBean.getCustImg2());

			customerDetailMap = new HashMap<String, Object>();
			customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.IMG_LIST, custSelfieDataList);
			customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID, customerRegBean.getClientId());
			customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID, customerRegBean.getCustomerId());

			imgUrlList = createImage(customerDetailMap);
			
			log.info("imgUrlList : " + imgUrlList);
			
			if (null != imgUrlList) 
			{
				return imgUrlList;
			} else {
				return imgUrlList;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.info("Exception in saving customer image is : " + e.getMessage(), e.getCause());
			return imgUrlList;
		}

	}

	/**
	 * @param customerDetailMap
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	private List<String> createImage(HashMap<String, Object> customerDetailMap) throws IOException {

	log.info("Inside ImageHelperService/createImage()");
		
		List<String> imgList = (ArrayList<String>) customerDetailMap
				.get(ApplicationConstants.APP_KEY_CONSTANTS.IMG_LIST);

		log.info("Img list is : " + imgList.size());
		
		String clientDir = null;
		String imgName = null;
		String imgUrl = null;
		List<String> imgUrlList = null;

		try {
			if (customerDetailMap.containsKey(ApplicationConstants.APP_KEY_CONSTANTS.IMG_DIR_PATH)) {
				clientDir = String.valueOf(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.IMG_DIR_PATH));
			} else {
				clientDir = isClientImgDirExists(customerDetailMap);
			}

			log.info("clientDir : " + clientDir);

			if (null != clientDir) 
			{
				imgUrlList = new ArrayList<String>();
				
				for (String img : imgList) {
					try {
						
						byte[] bytearray = Base64.getDecoder().decode(img.replaceAll("\n", ""));
						
						BufferedImage imag = ImageIO.read(new ByteArrayInputStream(bytearray));
						if (!customerDetailMap.containsKey(ApplicationConstants.APP_KEY_CONSTANTS.TO_BE_CHECK_IMG_NAME)) {
							imgName = getImageName(customerDetailMap);
							customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG, imgName);
							imgUrl = generateImgUrl(customerDetailMap);
							
							log.info("Customer image url is : " + imgUrl);
							
							imgUrlList.add(imgUrl);
						} else {
							imgName = String.valueOf(
									customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.TO_BE_CHECK_IMG_NAME));
							
							imgUrlList.add(imgName);
						}
						ImageIO.write(imag, ApplicationConstants.APP_KEY_CONSTANTS.JPG_IMG_EXTENSION, new File(clientDir, imgName));
					} catch (Exception e) {
						log.error("Exception in image writing : " + e.getMessage(),e.getCause());
						e.printStackTrace();
						return imgUrlList;
					}
				}

				log.info("image save succesfully!!");
				return imgUrlList;
			} else {
				return imgUrlList;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return imgUrlList;
		}

	}

	private String generateImgUrl(HashMap<String, Object> customerDetailMap) {
		log.info("Inside ImageHelperService/generateImgUrl()");
		
		StringBuilder imgUrlBuilder = new StringBuilder();
		imgUrlBuilder.append(faceRekogImgBaseUrl);
		imgUrlBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID);
		imgUrlBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.VALUE_ASSIGNER);
		imgUrlBuilder.append(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID));
		imgUrlBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.URL_APPENDER);
		imgUrlBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID);
		imgUrlBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.VALUE_ASSIGNER);
		imgUrlBuilder.append(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID));
		imgUrlBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.URL_APPENDER);
		imgUrlBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.IMAGE_ASSIGNER);
		imgUrlBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.VALUE_ASSIGNER);
		imgUrlBuilder.append(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG));
		
		log.info("Img url is : " + imgUrlBuilder.toString());
		
		return imgUrlBuilder.toString();
	}

	@Async
	public void addImageIntoTraningData(HashMap<String, Object> customerDetailMap) throws IOException {
		log.info("Inside ImageHelperService / saveImage()");

		String getImageName = getImageName(customerDetailMap);

		log.info("Customer detail map is : " + customerDetailMap);
		log.info("traning image name is : " + getImageName);

		StringBuilder imgFilePathBuilder = new StringBuilder(String.valueOf(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_KNOWN_FACE_DIR)));
		imgFilePathBuilder.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		imgFilePathBuilder.append(getImageName);
		
		
		Path temp = Files.move(
				Paths.get(String
						.valueOf(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY))),
				Paths.get(imgFilePathBuilder.toString()));

		if (temp != null) {
			log.info(" File moved successfully");
		} else {
			log.info("Failed to move the file");
		}

	}

	private String getImageName(HashMap<String, Object> customerDetailMap) {
		log.info("Inside ImageHelperService/getImageName()");

		StringBuilder custImgNameBuilder = new StringBuilder(); // FILE_NAME_SEPERATOR
		custImgNameBuilder.append(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID));
		custImgNameBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME_SEPERATOR);
		custImgNameBuilder.append(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID));
		custImgNameBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME_SEPERATOR);
		custImgNameBuilder.append(IdGenratorUtility.getSystemNanoTime());
		custImgNameBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.FILE_EXTENSION_BUILDER);
		custImgNameBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.JPG_IMG_EXTENSION);

		return custImgNameBuilder.toString();
	}

	private String isClientImgDirExists(HashMap<String, Object> customerDetailMap) {
		StringBuilder clientDirPathBuilder = new StringBuilder();
		clientDirPathBuilder.append(tranningImgDir);
		clientDirPathBuilder.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		clientDirPathBuilder
				.append(String.valueOf(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID)));
		clientDirPathBuilder.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		clientDirPathBuilder
		.append(String.valueOf(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID)));

		log.info("clientDirPathBuilder : " + clientDirPathBuilder.toString());

		File file = new File(clientDirPathBuilder.toString());

		if (!file.exists()) {
			if (file.mkdir()) {
				return file.getAbsolutePath();
			} else {
				return file.getAbsolutePath();
			}
		}

		return file.getAbsolutePath();
	}

	public String getCustomerImgFilePath(HashMap<String,String> custImgDataMap) {

		log.info("custImgDataMap : " + custImgDataMap);

		List<String> custImgDataList = null;
		HashMap<String, Object> customerDetailMap = null;

		try {

			custImgDataList = new ArrayList<String>();

			custImgDataList.add(custImgDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG));

			log.info("custImgDataList : " + custImgDataList);

			String imgName = getImgToBeCheckName();

			customerDetailMap = new HashMap<String, Object>();
			customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.IMG_LIST, custImgDataList);
			customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID,
					custImgDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID));
			customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID,
					custImgDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID));
			customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.TO_BE_CHECK_IMG_NAME, imgName);
			
			if(custImgDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.ACTION).equals(ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION))
			{
				customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.IMG_DIR_PATH, customerReqImgDir);
			}
			if(custImgDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.ACTION).equals(ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CUSTOMER_FACE_EXTRACTION))
			{
				customerDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.IMG_DIR_PATH, customerReqImgDir);
			}
			
			log.info("customerDetailMap : " + customerDetailMap);

			if (null != createImage(customerDetailMap)) {
				StringBuilder toBeCheckImgPathBuilder = new StringBuilder();
				toBeCheckImgPathBuilder.append(customerReqImgDir);
				toBeCheckImgPathBuilder.append(imgName);

				log.info("toBeCheckImgPathBuilder : " + toBeCheckImgPathBuilder.toString());

				return toBeCheckImgPathBuilder.toString();
			} else {
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.info("Exception in saving customer image is : " + e.getMessage(), e.getCause());
			return null;
		}
	}

	/**
	 * @return
	 */
	private String getImgToBeCheckName() {
		return IdGenratorUtility.getSystemNanoTime() + ApplicationConstants.APP_KEY_CONSTANTS.FILE_EXTENSION_BUILDER
				+ ApplicationConstants.APP_KEY_CONSTANTS.JPG_IMG_EXTENSION;
	}

}
