package com.infra.digital.controller;

import java.io.FileInputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infra.digital.commons.ApplicationConstants;

@RestController
@RequestMapping("/faceRekog")
@PropertySource("classpath:global.properties")
@ConfigurationProperties
public class ImageController {

	private Log log = LogFactory.getLog(this.getClass());

	@Value("${faceRekogBaseDir}")
	private String faceRekogBaseDir;
	
	/*
	 * http://localhost:8080/faceRekog/faceImage?clientId=HDFCXXX121&customerId=
	 * 989858828228079&img=HDFCXXX121_989858828228079_127969.jpg
	 */
	@RequestMapping(value = "/faceImage", method = RequestMethod.GET)
	public void getImage(@RequestParam("clientId") String clientId,
			@RequestParam("customerId") String customerId, @RequestParam("img") String imgName,HttpServletResponse response) {
		
		log.info("inside ImageController/getImage() ");

		if(log.isInfoEnabled())
		{
			log.info("Client id is : " + clientId);
			log.info("Customer id is : " + customerId);
			log.info("Img name is : " + imgName);
			log.info("faceRekogBaseDir is : " + faceRekogBaseDir);
		}
		
		StringBuilder imagePathBuilder = new StringBuilder();
		imagePathBuilder.append(faceRekogBaseDir);
		imagePathBuilder.append(clientId);
		imagePathBuilder.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		imagePathBuilder.append(customerId);
		imagePathBuilder.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		imagePathBuilder.append(imgName);
		
		log.info("imagePathBuilder : " + imagePathBuilder.toString());
		
		displayImage(imagePathBuilder.toString(),response);
		
		
		
	}

	private void displayImage(String imagePath, HttpServletResponse response) {
		FileInputStream fin = null;
		try
		{
			fin = new FileInputStream(imagePath.toString());
			byte[] bytes = new byte[1024];
			while (fin.read(bytes) != -1)
			{
				response.getOutputStream().write(bytes);
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			log.error("exception in image servlet is : " + e.getMessage(),e.getCause());
		}
		
	}

}
