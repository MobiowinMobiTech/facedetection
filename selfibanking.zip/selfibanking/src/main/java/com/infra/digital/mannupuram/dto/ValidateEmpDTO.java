package com.infra.digital.mannupuram.dto;

public class ValidateEmpDTO {

	private String apiKey;
	private String clientId;
	private String empId;
	private String name;
	private String mobileNo;
	private String deviceId;
	private String empImg;

	public ValidateEmpDTO() {
		super();
	}

	public ValidateEmpDTO(String apiKey, String clientId, String empId, String name, String mobileNo, String deviceId,
			String empImg) {
		super();
		this.apiKey = apiKey;
		this.clientId = clientId;
		this.empId = empId;
		this.name = name;
		this.mobileNo = mobileNo;
		this.deviceId = deviceId;
		this.empImg = empImg;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getEmpImg() {
		return empImg;
	}

	public void setEmpImg(String empImg) {
		this.empImg = empImg;
	}

	@Override
	public String toString() {
		return "ValidateEmpDTO [apiKey=" + apiKey + ", clientId=" + clientId + ", empId=" + empId + ", name=" + name
				+ ", mobileNo=" + mobileNo + ", deviceId=" + deviceId + ", empImg=" + empImg + "]";
	}

}
