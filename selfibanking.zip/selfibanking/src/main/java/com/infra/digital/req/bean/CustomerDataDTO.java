package com.infra.digital.req.bean;

import java.io.Serializable;

public class CustomerDataDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String custId;
	private String name;
	private String transLimit;
	private String mobileNo;
	private String mPin;
	private String currency;
	private String latitude;
	private String longitute;
	private String img1;
	private String img2;
	private String deviceId;

	public CustomerDataDTO() {
		super();
	}

	public CustomerDataDTO(String custId, String name, String transLimit, String mobileNo, String mPin, String currency,
			String latitude, String longitute, String img1, String img2, String deviceId) {
		super();
		this.custId = custId;
		this.name = name;
		this.transLimit = transLimit;
		this.mobileNo = mobileNo;
		this.mPin = mPin;
		this.currency = currency;
		this.latitude = latitude;
		this.longitute = longitute;
		this.img1 = img1;
		this.img2 = img2;
		this.deviceId = deviceId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTransLimit() {
		return transLimit;
	}

	public void setTransLimit(String transLimit) {
		this.transLimit = transLimit;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getmPin() {
		return mPin;
	}

	public void setmPin(String mPin) {
		this.mPin = mPin;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitute() {
		return longitute;
	}

	public void setLongitute(String longitute) {
		this.longitute = longitute;
	}

	public String getImg1() {
		return img1;
	}

	public void setImg1(String img1) {
		this.img1 = img1;
	}

	public String getImg2() {
		return img2;
	}

	public void setImg2(String img2) {
		this.img2 = img2;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	@Override
	public String toString() {
		return "CustomerDataDTO [custId=" + custId + ", name=" + name + ", transLimit=" + transLimit + ", mobileNo="
				+ mobileNo + ", mPin=" + mPin + ", currency=" + currency + ", latitude=" + latitude + ", longitute="
				+ longitute + ", img1=" + img1 + ", img2=" + img2 + ", deviceId=" + deviceId + "]";
	}

}
