package com.infra.digital.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.infra.digital.bean.CustomerRegBean;

public interface CustomerRepository extends MongoRepository<CustomerRegBean, String>,CustomCustomerRepository  {

	public List<CustomerRegBean> findByClientIdAndCustomerId(String clientId, String customerId);

	public List<CustomerRegBean> findByClientIdAndMobileNo(String clientId, String mobileNo);

	public List<CustomerRegBean> findByClientIdAndCustomerIdAndMobileNo(String clientId, String customerId,
			String mobileNo);

	public List<CustomerRegBean> findByClientIdAndMobileNoAndDeviceIdAndDelFlag(String clientId, String mobileNo,
			String deviceId, String delFlag);

	

}
