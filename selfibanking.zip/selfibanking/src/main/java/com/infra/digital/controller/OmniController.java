package com.infra.digital.controller;

import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.infra.digital.bean.User;

@RestController
public class OmniController {

	private Log log = LogFactory.getLog(this.getClass());

	@RequestMapping(value = "/face/test", method = RequestMethod.GET)
	public ModelAndView test(@RequestParam("name") String name, Model model) {
		log.info("inside SelfieController/listAllUsers() ");

		log.info("request is : " + name);

		ModelAndView mav = new ModelAndView("greetings");
		mav.addObject("name", "HOA v0.1");
		mav.addObject("pic",
				"https://upload.wikimedia.org/wikipedia/commons/8/80/Deepika_Padukone_at_Yonex_Sunrise_India_Open_2018_%28cropped%29.jpg");
		return mav;
	}

	@RequestMapping(value = "/face/verification", method = RequestMethod.POST)
	public ResponseEntity<String> registerClient(@Valid User user, BindingResult bindingResult) {

		log.info("user is : " + user);
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@RequestMapping(value = { "/", "/login" }, method = RequestMethod.GET)
	public ModelAndView welcome(Map<String, Object> model) {
		ModelAndView mav = new ModelAndView("login");
		return mav;
	}

	@RequestMapping(value = { "/validateLogin" }, method = RequestMethod.POST)
	public ModelAndView login(@Valid User user, BindingResult bindingResult) {
		log.info("inside SelfieController/login() ");

		ModelAndView mav = null;

		log.info("User details : " + user);
		
		if (user.getMobileNo().equals("8828228072") && user.getPassword().equals("1234")) {
			mav = new ModelAndView("dashboard");
			return mav;
		} else {
			mav = new ModelAndView("login");
			return mav;
		}

	}

}
