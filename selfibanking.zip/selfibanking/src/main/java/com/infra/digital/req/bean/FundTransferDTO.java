package com.infra.digital.req.bean;

import java.io.Serializable;

public class FundTransferDTO implements Serializable{

	private String mobileNo;
	private String toAccount;
	private String frmAccount;
	private String amount;
	private String remarks;
	
}
