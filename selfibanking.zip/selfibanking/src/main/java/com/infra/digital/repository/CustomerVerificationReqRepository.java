package com.infra.digital.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.infra.digital.req.bean.CustomerVerificationReqDTO;

public interface CustomerVerificationReqRepository extends MongoRepository<CustomerVerificationReqDTO, String>{

}
