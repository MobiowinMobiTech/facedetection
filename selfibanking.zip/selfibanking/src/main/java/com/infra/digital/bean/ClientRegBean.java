package com.infra.digital.bean;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "client_master")
public class ClientRegBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private int id;
	private String clientName;
	private String address;
	private String city;
	private String state;
	private String pinCode;
	private String emailId;
	private String mobileNo;
	private String apiKey;
	private String secKey;
	private String isAuthservice;
	private String isTransactionService;
	private String isUpdateSubscribe;
	private String createdBy;
	private Date createDt;
	private String updatedBy;
	private Date modifyDt;
	private String deviceId;
	private String delFlag;

	public ClientRegBean() {
		super();
	}

	public ClientRegBean(int id, String clientName, String address, String city, String state, String pinCode,
			String emailId, String mobileNo, String apiKey, String secKey, String isAuthservice,
			String isTransactionService, String isUpdateSubscribe, String createdBy, Date createDt, String updatedBy,
			Date modifyDt, String deviceId, String delFlag) {
		super();
		this.id = id;
		this.clientName = clientName;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.apiKey = apiKey;
		this.secKey = secKey;
		this.isAuthservice = isAuthservice;
		this.isTransactionService = isTransactionService;
		this.isUpdateSubscribe = isUpdateSubscribe;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.updatedBy = updatedBy;
		this.modifyDt = modifyDt;
		this.deviceId = deviceId;
		this.delFlag = delFlag;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getEmmailId() {
		return emailId;
	}

	public void setEmmailId(String emmailId) {
		this.emailId = emmailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	public String getSecKey() {
		return secKey;
	}

	public void setSecKey(String secKey) {
		this.secKey = secKey;
	}

	public String getIsAuthservice() {
		return isAuthservice;
	}

	public void setIsAuthservice(String isAuthservice) {
		this.isAuthservice = isAuthservice;
	}

	public String getIsTransactionService() {
		return isTransactionService;
	}

	public void setIsTransactionService(String isTransactionService) {
		this.isTransactionService = isTransactionService;
	}

	public String getIsUpdateSubscribe() {
		return isUpdateSubscribe;
	}

	public void setIsUpdateSubscribe(String isUpdateSubscribe) {
		this.isUpdateSubscribe = isUpdateSubscribe;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	@Override
	public String toString() {
		return "ClientRegBean [id=" + id + ", clientName=" + clientName + ", address=" + address + ", city=" + city
				+ ", state=" + state + ", pinCode=" + pinCode + ", emailId=" + emailId + ", mobileNo=" + mobileNo
				+ ", apiKey=" + apiKey + ", secKey=" + secKey + ", isAuthservice=" + isAuthservice
				+ ", isTransactionService=" + isTransactionService + ", isUpdateSubscribe=" + isUpdateSubscribe
				+ ", createdBy=" + createdBy + ", createDt=" + createDt + ", updatedBy=" + updatedBy + ", modifyDt="
				+ modifyDt + ", deviceId=" + deviceId + ", delFlag=" + delFlag + "]";
	}

}
