package com.infra.digital.util;

import java.io.IOException;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.infra.digital.commons.ApplicationConstants;

import net.bramp.ffmpeg.FFmpeg;
import net.bramp.ffmpeg.FFmpegExecutor;
import net.bramp.ffmpeg.FFprobe;
import net.bramp.ffmpeg.builder.FFmpegBuilder;

public class VedioForamtConvertionUtil {

	private static Log log = LogFactory.getLog(VedioForamtConvertionUtil.class);

	private static final String ffmpegPath = "E:\\ffmeg\\ffmpeg\\bin\\ffmpeg.exe";

	private static final String ffprobePath = "E:\\ffmeg\\ffmpeg\\bin\\ffprobe.exe";

	public static boolean vedioFormaConversion(HashMap<String, String> custBlinkMap) {
		log.info("Inside VedioForamtConvertionUtil/vedioFormaConversion()");

		try {
			
			if(log.isInfoEnabled())
			{
				log.info("custBlinkMap data is : " + custBlinkMap);
			}
			
			FFmpeg ffmpeg = new FFmpeg(ffmpegPath);
			FFprobe ffprobe = new FFprobe(ffprobePath);

			FFmpegBuilder builder = new FFmpegBuilder()

					.setInput(custBlinkMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_PATH)).overrideOutputFiles(true)

					.addOutput(custBlinkMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_UPLOAD_LOCATION)+ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR+
							custBlinkMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME).substring(0, custBlinkMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME).lastIndexOf("."))+".avi").setFormat("avi")
					//.setTargetSize(80_000)

					.disableSubtitle()

					.setVideoResolution(640, 480)

					.setStrict(FFmpegBuilder.Strict.EXPERIMENTAL).done();

			FFmpegExecutor executor = new FFmpegExecutor(ffmpeg, ffprobe);

			executor.createJob(builder).run();

		} catch (IOException ex) 
		{
			log.error("IOException in VedioForamtConvertionUtil/vedioFormaConversion() : " + ex.getMessage(),ex.getCause());
			return false;

		} catch (Exception ex) {

			log.error("Exception in VedioForamtConvertionUtil/vedioFormaConversion() : " + ex.getMessage(),ex.getCause());
			return false;
		}

		return true;
	}

}
