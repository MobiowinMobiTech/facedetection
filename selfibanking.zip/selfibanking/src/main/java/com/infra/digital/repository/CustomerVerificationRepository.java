package com.infra.digital.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.infra.digital.bean.CustomerVerificationBean;

public interface CustomerVerificationRepository extends MongoRepository<CustomerVerificationBean, String>{

}
