package com.infra.digital.mannupuram.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.infra.digital.mannupuram.bean.Employee;

public interface EmployeeRepository extends MongoRepository<Employee, String>{
	
	public List<Employee> findByempId(String empId);
}
