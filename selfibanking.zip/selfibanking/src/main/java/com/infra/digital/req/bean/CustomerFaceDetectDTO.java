package com.infra.digital.req.bean;

import java.io.Serializable;

public class CustomerFaceDetectDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String clientId;
	private String apiKey;
	private CustomerDataDTO custData;

	public CustomerFaceDetectDTO() {
		super();
	}

	public CustomerFaceDetectDTO(String clientId, String apiKey, CustomerDataDTO custData) {
		super();
		this.clientId = clientId;
		this.apiKey = apiKey;
		this.custData = custData;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	public CustomerDataDTO getCustData() {
		return custData;
	}

	public void setCustData(CustomerDataDTO custData) {
		this.custData = custData;
	}

	@Override
	public String toString() {
		return "CustomerFaceDetectDTO [clientId=" + clientId + ", apiKey=" + apiKey + ", custData=" + custData + "]";
	}

}
