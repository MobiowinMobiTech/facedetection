package com.infra.digital.mannapuram.service;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.infra.digital.bean.ResponseBean;
import com.infra.digital.commons.ApplicationConstants;
import com.infra.digital.helper.CustomerImgVerifyService;
import com.infra.digital.mannapuram.helper.MannapuramImgHelperService;
import com.infra.digital.mannupuram.bean.Employee;
import com.infra.digital.mannupuram.dto.ValidateEmpDTO;
import com.infra.digital.mannupuram.repository.EmployeeRepository;
import com.infra.digital.util.ApplicationUtility;

@Component
@PropertySource("classpath:global.properties")
@ConfigurationProperties
public class EmpCoreService implements IEmpCoreService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private MannapuramImgHelperService mImgHelperService;

	@Autowired
	private CustomerImgVerifyService customerImgVerificationService;

	@Autowired
	private EmployeeRepository employeeRepository;

	@Value("${empImgDir}")
	private String empImgDir;

	@Override
	public String validateCustomer(ValidateEmpDTO req) {
		log.info("Inside EmpCoreService / validateCustomer()");

		Employee employee = null;
		HashMap<String, Object> responseMap = null;
		HashMap<String, String> responseDataMap = null;
		List<String> imgUrlList = null;
		HashMap<String, Object> faceDetectionMap = null;
		HashMap<String, String> faceDetectionResMap = null;
		String imageToBeVerifyPath = null;
		String faceExtractionResponse = null;
		HashMap<String, Object> toBeVerifyDataMap = null;
		String verifyImgResponse = null;
		String empId = null;
		HashMap<String, String> empImgDataMap = null;

		try {
			if (null != req) {
				employee = new Employee();
				employee.setClientId(req.getClientId());
				employee.setDeviceId(req.getDeviceId());
				employee.setEmpImg(req.getEmpImg());

				log.info("employee bean is : " + employee);

				imgUrlList = mImgHelperService.saveCustomerImage(employee);

				log.info("imageToBeVerifyPath : " + imgUrlList.get(0));

				if (null != imgUrlList && imgUrlList.size() > 0) {

					log.info("imageToBeVerifyPath : " + imgUrlList.get(0));

					imageToBeVerifyPath = imgUrlList.get(0);

					faceDetectionMap = new HashMap<String, Object>();
					faceDetectionMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_EXTRACT,
							imageToBeVerifyPath);

					faceExtractionResponse = customerImgVerificationService.customerFaceExtraction(faceDetectionMap);

					faceDetectionResMap = processFaceDetectionResponse(faceExtractionResponse);

					log.info("faceDetectionResMap : " + faceDetectionResMap);

					if (faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
							.equals(ApplicationConstants.APP_VALUE_CONSTANTS.SUCCESS)) {

						toBeVerifyDataMap = new HashMap<String, Object>();
						toBeVerifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY,
								faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_PATH));
						toBeVerifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.ACTION,
								ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_LOGIN);

						verifyImgResponse = customerImgVerificationService.empFaceRekogn(toBeVerifyDataMap);

						if (null != verifyImgResponse) {

							log.info("Face recognition response : " + verifyImgResponse);

							empId = processImageVerificationRes(verifyImgResponse);
							List<Employee> empDeatilsList = employeeRepository.findByempId(empId);

							log.info("Empdetails list is : " + empDeatilsList);

							if (null != empId) {

								responseMap = new HashMap<String, Object>();
								responseMap.put(ApplicationConstants.MANNAPURAM_APP_KEY_CONSTANTS.EMP_ID, empId);

								if (empDeatilsList.size() > 0 && null != empDeatilsList) {
									responseMap.put(ApplicationConstants.APP_KEY_CONSTANTS.NAME,
											empDeatilsList.get(0).getName());
								}

								empImgDataMap = new HashMap<String, String>();
								empImgDataMap.put(ApplicationConstants.MANNAPURAM_APP_KEY_CONSTANTS.EMP_ID, empId);
								empImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY,
										imageToBeVerifyPath);
								empImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG,
										employee.getEmpImg());

								mImgHelperService.saveEmpImg(empImgDataMap);

								return ApplicationUtility.createSuccessMessage(responseMap,
										ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_LOGIN);
							} else {
								return ApplicationUtility.createErrorMessage(
										ApplicationConstants.APP_MESSAGES.FACE_RECOG_ERR_MSG,
										ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_LOGIN);
							}

						}

					}

					if (faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
							.equals(ApplicationConstants.FACE_DETECTION_MESSAGES_CODES.MULTIPLE_FACE_FOUND)) {
						return ApplicationUtility.createErrorMessage(
								ApplicationConstants.APP_MESSAGES.MULTIPLE_FACE_FOUND,
								ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_LOGIN);
					}

				}

			}
		} catch (Exception e) {
			return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
					ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
		}

		return null;
	}

	@Override
	public String generateErrResponse(String genericErrMsg) {
		log.info("Inside EmpCoreService / generateErrResponse()");

		return null;
	}

	private String processImageVerificationRes(String verifyImgResponse) {
		log.info("inside CustomerCoreService/processImageVerificationRes()");

		List<ResponseBean> faceRekogResList = null;
		ResponseBean responseBean = null;
		HashMap<String, Double> resMap = null;
		boolean isMatchFound = false;
		Map<String, Double> dataMap = null;
		String empId = null;
		try {
			JSONObject responseJson = new JSONObject(verifyImgResponse);
			JSONArray array = (JSONArray) responseJson.get(ApplicationConstants.APP_KEY_CONSTANTS.RESPONSE);

			log.info("array is : " + array);

			if (array.length() > 0) {
				faceRekogResList = new ArrayList<ResponseBean>();
				for (int i = 0; i < array.length(); i++) {

					if (Boolean
							.valueOf(array.getJSONObject(i).getBoolean(ApplicationConstants.APP_KEY_CONSTANTS.IS_MATCH))
							.booleanValue()) {

						responseBean = new ResponseBean();
						responseBean.setDistance(BigDecimal
								.valueOf(array.getJSONObject(i)
										.getDouble(ApplicationConstants.APP_KEY_CONSTANTS.IMAGE_DISTANCE))
								.doubleValue());
						responseBean.setEmpId(String.valueOf(
								array.getJSONObject(i).get(ApplicationConstants.MANNAPURAM_APP_KEY_CONSTANTS.NAME)));

						faceRekogResList.add(responseBean);

					}
				}

				log.info("faceRekogResList is : " + faceRekogResList);
				log.info("faceRekogResList is : " + faceRekogResList.size());

				dataMap = new HashMap<String, Double>();

				for (ResponseBean resBean : faceRekogResList) {
					dataMap.put(resBean.getEmpId(), resBean.getDistance());
				}

				log.info("Datamap is : " + dataMap);

				Entry<String, Double> empFacceMatchMap = Collections.min(dataMap.entrySet(),
						new Comparator<Entry<String, Double>>() {
							public int compare(Entry<String, Double> entry1, Entry<String, Double> entry2) {
								return entry1.getValue().compareTo(entry2.getValue());
							}
						});

				empId = empFacceMatchMap.getKey();
				System.out.printf("%s: %f", empFacceMatchMap.getKey(), empFacceMatchMap.getValue());

				return empId;

				/*
				 * if (faceRekogResList.size() >= 1) return true; else return false;
				 */
			}

		} catch (JSONException e) {
			e.printStackTrace();
			log.error("Exception in resposne parsing : " + e.getMessage(), e.getCause());
			return empId;
		}
		return empId;

	}

	private HashMap<String, String> processFaceDetectionResponse(String faceExtractionResponse) {
		log.info("inside CustomerCoreService/processFaceDetectionResponse()");

		HashMap<String, String> resMap = null;
		JSONObject responseJson = null;

		if (null != faceExtractionResponse) {
			resMap = new HashMap<String, String>();
			responseJson = new JSONObject(faceExtractionResponse);

			resMap.put(ApplicationConstants.APP_KEY_CONSTANTS.STATUS,
					responseJson.getString(ApplicationConstants.APP_KEY_CONSTANTS.STATUS));

			resMap.put(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE,
					responseJson.getString(ApplicationConstants.APP_KEY_CONSTANTS.MESSAGE));

			if (responseJson.getString(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
					.equals(ApplicationConstants.FACE_DETECTION_MESSAGES_CODES.FACE_FOUND)) {

				resMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_PATH,
						responseJson.getJSONObject(ApplicationConstants.APP_KEY_CONSTANTS.DATA)
								.getString(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_PATH));
			}

			return resMap;

		}

		return resMap;
	}

	@Override
	public String verifyCustomer(ValidateEmpDTO req) {
		log.info("inside CustomerCoreService/verifyCustomer()");

		Employee employee = null;
		HashMap<String, Object> responseMap = null;
		HashMap<String, String> responseDataMap = null;
		List<String> imgUrlList = null;
		HashMap<String, Object> faceDetectionMap = null;
		HashMap<String, String> faceDetectionResMap = null;
		String imageToBeVerifyPath = null;
		String faceExtractionResponse = null;
		HashMap<String, Object> toBeVerifyDataMap = null;
		String verifyImgResponse = null;
		String empId = null;
		HashMap<String, String> empImgDataMap = null;

		try {
			if (null != req) {
				employee = new Employee();
				employee.setClientId(req.getClientId());
				employee.setDeviceId(req.getDeviceId());
				employee.setEmpImg(req.getEmpImg());
				employee.setEmpId(req.getEmpId());

				log.info("employee bean is : " + employee);

				imgUrlList = mImgHelperService.saveCustomerImage(employee);

				boolean isExists = isEmployeeDirExists(employee, empImgDir);

				log.info("imageToBeVerifyPath : " + imgUrlList.get(0));

				if (isExists) {
					if (null != imgUrlList && imgUrlList.size() > 0) {

						log.info("imageToBeVerifyPath : " + imgUrlList.get(0));

						imageToBeVerifyPath = imgUrlList.get(0);

						faceDetectionMap = new HashMap<String, Object>();
						faceDetectionMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_EXTRACT,
								imageToBeVerifyPath);
						faceExtractionResponse = customerImgVerificationService
								.customerFaceExtraction(faceDetectionMap);

						faceDetectionResMap = processFaceDetectionResponse(faceExtractionResponse);

						log.info("faceDetectionResMap : " + faceDetectionResMap);

						if (faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
								.equals(ApplicationConstants.APP_VALUE_CONSTANTS.SUCCESS)) {

							toBeVerifyDataMap = new HashMap<String, Object>();
							toBeVerifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY,
									faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_PATH));
							toBeVerifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.ACTION,
									ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
							toBeVerifyDataMap.put(ApplicationConstants.MANNAPURAM_APP_KEY_CONSTANTS.EMP_ID,
									employee.getEmpId());

							verifyImgResponse = customerImgVerificationService.empFaceRekogn(toBeVerifyDataMap);

							if (null != verifyImgResponse) {

								log.info("Face rekognization response : " + verifyImgResponse);

								empId = processImageVerificationRes(verifyImgResponse);

								if (null != empId) {

									responseMap = new HashMap<String, Object>();
									responseMap.put(ApplicationConstants.MANNAPURAM_APP_KEY_CONSTANTS.EMP_ID, empId);

									log.info("Response map is : " + responseMap);

									empImgDataMap = new HashMap<String, String>();
									empImgDataMap.put(ApplicationConstants.MANNAPURAM_APP_KEY_CONSTANTS.EMP_ID,
											req.getEmpId());
									empImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY,
											imageToBeVerifyPath);
									empImgDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG,
											employee.getEmpImg());

									mImgHelperService.saveEmpImg(empImgDataMap);

									return ApplicationUtility.createSuccessMessage(
											ApplicationConstants.APP_MESSAGES.GENERIC_SUCCESS_MSG,
											ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
								} else {
									return ApplicationUtility.createErrorMessage(
											ApplicationConstants.APP_MESSAGES.FACE_RECOG_ERR_MSG,
											ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
								}

							}

						}

						if (faceDetectionResMap.get(ApplicationConstants.APP_KEY_CONSTANTS.STATUS)
								.equals(ApplicationConstants.FACE_DETECTION_MESSAGES_CODES.MULTIPLE_FACE_FOUND)) {
							return ApplicationUtility.createErrorMessage(
									ApplicationConstants.APP_MESSAGES.MULTIPLE_FACE_FOUND,
									ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
						}

					}
				} else {
					return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.USER_NOT_FOUND,
							ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_VERIFICATION);
				}

			}
		} catch (Exception ex) {

			log.error("Exception in verifyCustomer : " + ex.getMessage(), ex.getCause());

		}
		return null;
	}

	private boolean isEmployeeDirExists(Employee employee, String empImgDir2) {
		File file = new File(empImgDir + employee.getEmpId());

		log.info("Employee id is : " + employee.getEmpId());

		if (file.exists()) {

			return true;
		}

		return false;
	}

}
