package com.infra.digital.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ImageVerificationResponseBean {

	private List<ResponseBean> response;

	public ImageVerificationResponseBean(List<ResponseBean> response) {
		super();
		this.response = response;
	}

	public ImageVerificationResponseBean() {
		super();
	}

	public List<ResponseBean> getListResponseBean() {
		return response;
	}

	public void setListResponseBean(List<ResponseBean> listResponseBean) {
		this.response = listResponseBean;
	}

	@Override
	public String toString() {
		return "ImageVerificationResponseBean [listResponseBean=" + response + "]";
	}
	
	
	
}
