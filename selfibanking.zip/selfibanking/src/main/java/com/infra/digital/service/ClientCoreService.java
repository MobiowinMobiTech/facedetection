package com.infra.digital.service;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.infra.digital.bean.ClientRegBean;
import com.infra.digital.commons.ApplicationConstants;
import com.infra.digital.repository.ClientRepository;
import com.infra.digital.req.bean.ClientRegReqDTO;
import com.infra.digital.util.ApplicationUtility;
import com.infra.digital.util.IdGenratorUtility;

@Component
public class ClientCoreService implements IClientCoreService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ClientRepository clientRepository;

	@Override
	public boolean validateClient(ClientRegReqDTO clientRegReq) {
		log.info("Inside ClientCoreService/validateClient() ");

		List<ClientRegBean> clientList = clientRepository.findByMobileNoAndEmailIdAndDelFlag(clientRegReq.getMobileNo(),
				clientRegReq.getEmailId(), "F");

		log.info("clientList size is : " + clientList.size());

		if (clientList.size() == 0) {
			return true;
		}

		return false;
	}

	@Override
	public String registerClient(ClientRegReqDTO clientRegReq) {
		log.info("Inside ClientCoreService/registerClient() ");

		String apiKey = null;
		String secKey = null;
		String clientId = null;

		ClientRegBean clientRegBean = null;
		HashMap<String, Object> responseMap = null;

		try {
			apiKey = IdGenratorUtility.generateApiKey(clientRegReq);
			secKey = IdGenratorUtility.generateSecKey();
			clientId = IdGenratorUtility.generateClientId(clientRegReq);

			if (log.isInfoEnabled()) {
				log.info("Client api key is : " + apiKey);
				log.info("Client sec key is : " + secKey);
				log.info("Client id is : " + Integer.parseInt(clientId));
			}

			clientRegBean = new ClientRegBean();

			clientRegBean.setId(Integer.valueOf(clientId));

			clientRegBean.setClientName(clientRegReq.getName());
			clientRegBean.setApiKey(apiKey);
			clientRegBean.setSecKey(secKey);
			clientRegBean.setEmmailId(clientRegReq.getEmailId());
			clientRegBean.setMobileNo(clientRegReq.getMobileNo());
			clientRegBean.setAddress(clientRegReq.getAddress());
			clientRegBean.setCity(clientRegReq.getCity());
			clientRegBean.setState(clientRegReq.getState());
			clientRegBean.setPinCode(clientRegReq.getPinCode());
			clientRegBean.setIsAuthservice(clientRegReq.getIsLoginAuth());
			clientRegBean.setIsTransactionService(clientRegReq.getIsTransactionAuth());
			clientRegBean.setIsUpdateSubscribe(clientRegReq.getIsUpdateSubscribe());
			clientRegBean.setDelFlag(ApplicationConstants.APP_VALUE_CONSTANTS.DEL_FLAG_INACTIVE);

			log.info("clientRegBean is : " + clientRegBean);

			clientRepository.save(clientRegBean);

			responseMap = new HashMap<String, Object>();
			responseMap.put(ApplicationConstants.APP_KEY_CONSTANTS.API_KEY, clientRegBean.getApiKey());
			responseMap.put(ApplicationConstants.APP_KEY_CONSTANTS.SEC_KEY, clientRegBean.getSecKey());
			responseMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID, String.valueOf(clientRegBean.getId()));

			return ApplicationUtility.createSuccessMessage(responseMap,
					ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CLIENT_REGISTRATION);

		} catch (Exception ex) {
			ex.printStackTrace();
			log.error("Exception in generating id for client : " + ex.getMessage(), ex.getCause());
			return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
					ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CLIENT_REGISTRATION);
		}

	}

	@Override
	public String generateErrResponse() {
		return ApplicationUtility.createErrorMessage(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG,
				ApplicationConstants.APP_ACTION_CONSTANTS.ACTION_CLIENT_REGISTRATION);

	}

}
