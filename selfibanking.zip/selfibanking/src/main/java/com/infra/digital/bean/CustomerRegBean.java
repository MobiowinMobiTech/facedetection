package com.infra.digital.bean;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "customer_master")
public class CustomerRegBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	@Id
	private String id;
	private String clientId;
	private String customerId;
	private String name;
	private String mPin;
	private String mobileNo;
	private Double transactionLimit;
	private String currency;
	private Long latitude;
	private Long longitute;
	private String custImg1;
	private String custImg2;
	private String deviceId;
	private String createdBy;
	private Date createDt;
	private String updatedBy;
	private Date modifyDt;
	private String delFlag;

	public CustomerRegBean() {
		super();
	}

	
	public CustomerRegBean(String id, String clientId, String customerId, String name, String mPin, String mobileNo,
			Double transactionLimit, String currency, Long latitude, Long longitute, String custImg1, String custImg2,
			String deviceId, String createdBy, Date createDt, String updatedBy, Date modifyDt, String delFlag) {
		super();
		this.id = id;
		this.clientId = clientId;
		this.customerId = customerId;
		this.name = name;
		this.mPin = mPin;
		this.mobileNo = mobileNo;
		this.transactionLimit = transactionLimit;
		this.currency = currency;
		this.latitude = latitude;
		this.longitute = longitute;
		this.custImg1 = custImg1;
		this.custImg2 = custImg2;
		this.deviceId = deviceId;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.updatedBy = updatedBy;
		this.modifyDt = modifyDt;
		this.delFlag = delFlag;
	}


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getmPin() {
		return mPin;
	}

	public void setmPin(String mPin) {
		this.mPin = mPin;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Double getTransactionLimit() {
		return transactionLimit;
	}

	public void setTransactionLimit(Double transactionLimit) {
		this.transactionLimit = transactionLimit;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Long getLatitude() {
		return latitude;
	}

	public void setLatitude(Long latitude) {
		this.latitude = latitude;
	}

	public Long getLongitute() {
		return longitute;
	}

	public void setLongitute(Long longitute) {
		this.longitute = longitute;
	}

	public String getCustImg1() {
		return custImg1;
	}

	public void setCustImg1(String custImg1) {
		this.custImg1 = custImg1;
	}

	public String getCustImg2() {
		return custImg2;
	}

	public void setCustImg2(String custImg2) {
		this.custImg2 = custImg2;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	

	public String getDeviceId() {
		return deviceId;
	}


	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}


	@Override
	public String toString() {
		return "CustomerRegBean [id=" + id + ", clientId=" + clientId + ", customerId=" + customerId + ", name=" + name
				+ ", mPin=" + mPin + ", mobileNo=" + mobileNo + ", transactionLimit=" + transactionLimit + ", currency="
				+ currency + ", latitude=" + latitude + ", longitute=" + longitute + ", custImg1=" + custImg1
				+ ", custImg2=" + custImg2 + ", deviceId=" + deviceId + ", createdBy=" + createdBy + ", createDt="
				+ createDt + ", updatedBy=" + updatedBy + ", modifyDt=" + modifyDt + ", delFlag=" + delFlag + "]";
	}

	

	
}
