package com.infra.digital.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.infra.digital.bean.ClientRegBean;

public interface ClientRepository extends MongoRepository<ClientRegBean, String>{

	public List<ClientRegBean> findByApiKey(String apiKey);
	
	public List<ClientRegBean> findByMobileNoAndEmailIdAndDelFlag(String mobileNo, String emailId,String DelFlag);
	
	public List<ClientRegBean> findByApiKeyAndDelFlag(String apiKey,String delFlag);
}
