package com.infra.digital.helper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.infra.digital.bean.CustomerVerificationBean;
import com.infra.digital.commons.ApplicationConstants;

@Component
@PropertySource("classpath:global.properties")
@ConfigurationProperties
public class CustomerHelperService {

	private Log log = LogFactory.getLog(this.getClass());

	@Value("${traningImgDir}")
	private String tranningImgDir;

	@Value("${blinkVideoDir}")
	private String blinkVideoDir;

	public String isCustomerRegister(CustomerVerificationBean customerVerificationBean) {
		log.info("Inside CustomerHelperService/isCustomerRegister()");

		StringBuilder customerDirPathBuilder = getCustomerDirPath(customerVerificationBean);

		log.info("customerDirPathBuilder : " + customerDirPathBuilder.toString());

		File file = new File(customerDirPathBuilder.toString());

		if (file.exists()) {
			return file.getAbsolutePath();
		} else
			return null;

	}

	/**
	 * @param customerVerificationBean
	 * @return
	 */
	private StringBuilder getCustomerDirPath(CustomerVerificationBean customerVerificationBean) {
		StringBuilder customerDirPathBuilder = new StringBuilder();
		customerDirPathBuilder.append(tranningImgDir);
		// customerDirPathBuilder.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		customerDirPathBuilder.append(customerVerificationBean.getClientId());
		customerDirPathBuilder.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		customerDirPathBuilder.append(customerVerificationBean.getCustomerId());
		return customerDirPathBuilder;
	}

	public boolean isCustomerTraningDataPresent(CustomerVerificationBean customerVerificationBean) {
		log.info("Inside CustomerHelperService/isCustomerTraningDataPresent()");

		StringBuilder customerDirPathBuilder = getCustomerDirPath(customerVerificationBean);

		File dir = new File(customerDirPathBuilder.toString());

		File[] matches = dir.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.endsWith(ApplicationConstants.APP_KEY_CONSTANTS.FILE_EXTENSION_BUILDER
						+ ApplicationConstants.APP_KEY_CONSTANTS.JPG_IMG_EXTENSION);
			}
		});
		;

		if (matches.length > 0) {
			return true;
		}
		return false;
	}

	public String writeFile(MultipartFile file) {
		log.info("inside CustomerHelperService/writeFile()");

		String fileName = null;
		String uploadedFileLocation = null;
		try {
			fileName = file.getOriginalFilename();
			
			log.info("File name is : " + fileName);

			uploadedFileLocation = getUploadedFileLocation(fileName);
			
			log.info("Upload file location is : " + uploadedFileLocation);

			OutputStream out = new FileOutputStream(new File(uploadedFileLocation));
			int read = 0;
			byte[] bytes = new byte[1024];

			out = new FileOutputStream(new File(uploadedFileLocation));
			while ((read = file.getInputStream().read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			
			out.flush();
			out.close();
		} catch (IOException e) {
			log.error("IOException in viedo file writing : " + e.getMessage(),e.getCause());
			e.printStackTrace();
			return null;
			
		}
		catch(Exception e)
		{
			log.error("Exception in viedo file writing : " + e.getMessage(),e.getCause());
			e.printStackTrace();
			return null;
		}
		
		return uploadedFileLocation;

	}

	private String getUploadedFileLocation(String fileName) {
		log.info("inside CustomerHelperService/getUploadedFileLocation()");

		StringBuilder uploadFileLocationBuilder = new StringBuilder();
		uploadFileLocationBuilder.append(blinkVideoDir);
		uploadFileLocationBuilder.append(fileName);

		return uploadFileLocationBuilder.toString();
	}

	
}
