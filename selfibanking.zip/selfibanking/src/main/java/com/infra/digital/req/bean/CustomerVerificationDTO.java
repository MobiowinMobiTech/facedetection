package com.infra.digital.req.bean;

import java.io.Serializable;

public class CustomerVerificationDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String custId;
	private String name;
	private String transAmt;
	private String currency;
	private String custImg;

	public CustomerVerificationDTO() {
		super();
	}

	public CustomerVerificationDTO(String custId, String name, String transAmt, String currency, String custImg) {
		super();
		this.custId = custId;
		this.name = name;
		this.transAmt = transAmt;
		this.currency = currency;
		this.custImg = custImg;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCustImg() {
		return custImg;
	}

	public void setCustImg(String custImg) {
		this.custImg = custImg;
	}

	@Override
	public String toString() {
		return "CustomerVerificationDataBean [custId=" + custId + ", name=" + name + ", transAmt=" + transAmt
				+ ", currency=" + currency + ", custImg=" + custImg + "]";
	}

}
