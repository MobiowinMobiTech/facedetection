package com.infra.digital.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infra.digital.commons.ApplicationConstants;
import com.infra.digital.mannapuram.service.IEmpCoreService;
import com.infra.digital.mannupuram.dto.ValidateEmpDTO;

@RestController
@RequestMapping("/employee")
public class MannapuramController {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IEmpCoreService empCoreService;

	@RequestMapping(value = "/payment/login", method = RequestMethod.POST)
	public ResponseEntity<String> validateCustomer(@RequestBody ValidateEmpDTO req) {

		log.info("Inside MannapuramController / validateCustomer()");

		String response = null;

		if (log.isInfoEnabled()) {
			log.info("Validate Employee request is : " + req);
		}

		try {
			response = empCoreService.validateCustomer(req);
			return new ResponseEntity<String>(response, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in valdate customer : " + e.getMessage(), e.getCause());
			e.printStackTrace();
			response = empCoreService.generateErrResponse(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG);
			return new ResponseEntity<String>(response, HttpStatus.EXPECTATION_FAILED);
		}

	}

	
	@RequestMapping(value = "/payment/verification", method = RequestMethod.POST)
	public ResponseEntity<String> verifyEmployee(@RequestBody ValidateEmpDTO req) {

		log.info("Inside MannapuramController / verifyEmployee()");

		String response = null;

		if (log.isInfoEnabled()) {
			log.info("Verify Employee request is : " + req);
		}

		try {
			response = empCoreService.verifyCustomer(req);
			return new ResponseEntity<String>(response, HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception in valdate customer : " + e.getMessage(), e.getCause());
			e.printStackTrace();
			response = empCoreService.generateErrResponse(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG);
			return new ResponseEntity<String>(response, HttpStatus.EXPECTATION_FAILED);
		}

	}

	
}
