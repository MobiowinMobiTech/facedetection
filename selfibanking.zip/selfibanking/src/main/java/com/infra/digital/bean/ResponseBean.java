package com.infra.digital.bean;

public class ResponseBean {

	private Double distance;
	private boolean ismatch;
	private String empId;
	
	
	public ResponseBean() {
		super();
	}


	public ResponseBean(Double distance, boolean ismatch, String empId) {
		super();
		this.distance = distance;
		this.ismatch = ismatch;
		this.empId = empId;
	}


	public Double getDistance() {
		return distance;
	}


	public void setDistance(Double distance) {
		this.distance = distance;
	}


	public boolean isIsmatch() {
		return ismatch;
	}


	public void setIsmatch(boolean ismatch) {
		this.ismatch = ismatch;
	}


	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}


	@Override
	public String toString() {
		return "ResponseBean [distance=" + distance + ", ismatch=" + ismatch + ", empId=" + empId + "]";
	}


	
	
	
	
}
