package com.infra.digital.req.bean;

import java.io.Serializable;
import java.util.List;

public class ClientRegReqDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String address;
	private String city;
	private String state;
	private String pinCode;
	private String emailId;
	private String mobileNo;
	private String isUpdateSubscribe;
	private String isLoginAuth;
	private String isTransactionAuth;
	// private List<ReqServices> services;

	public ClientRegReqDTO() {
		super();
	}

	public ClientRegReqDTO(String name, String address, String city, String state, String pinCode, String emailId,
			String mobileNo, String isUpdateSubscribe, String isLoginAuth, String isTransactionAuth) {
		super();
		this.name = name;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.isUpdateSubscribe = isUpdateSubscribe;
		this.isLoginAuth = isLoginAuth;
		this.isTransactionAuth = isTransactionAuth;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getIsUpdateSubscribe() {
		return isUpdateSubscribe;
	}

	public void setIsUpdateSubscribe(String isUpdateSubscribe) {
		this.isUpdateSubscribe = isUpdateSubscribe;
	}

	public String getIsLoginAuth() {
		return isLoginAuth;
	}

	public void setIsLoginAuth(String isLoginAuth) {
		this.isLoginAuth = isLoginAuth;
	}

	public String getIsTransactionAuth() {
		return isTransactionAuth;
	}

	public void setIsTransactionAuth(String isTransactionAuth) {
		this.isTransactionAuth = isTransactionAuth;
	}

	@Override
	public String toString() {
		return "ClientRegReqBean [name=" + name + ", address=" + address + ", city=" + city + ", state=" + state
				+ ", pinCode=" + pinCode + ", emailId=" + emailId + ", mobileNo=" + mobileNo + ", isUpdateSubscribe="
				+ isUpdateSubscribe + ", isLoginAuth=" + isLoginAuth + ", isTransactionAuth=" + isTransactionAuth + "]";
	}

}
