package com.infra.digital.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infra.digital.req.bean.ClientRegReqDTO;
import com.infra.digital.service.IClientCoreService;

@RestController
@RequestMapping("/selfie")
public class ClientController {

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IClientCoreService clientCoreService;
	
	@RequestMapping(value = "/client/registration", method = RequestMethod.GET)
    public ResponseEntity<String> listAllUsers(@RequestParam("name") String name) 
	{
		log.info("inside SelfieController/listAllUsers() ");
       
		log.info("request is : " + name);
		
        return new ResponseEntity<String>(HttpStatus.OK);
    }
	
	
	@RequestMapping(value = "/payment/registration", method = RequestMethod.POST)
    public ResponseEntity<String> registerClient(@RequestBody ClientRegReqDTO clientRegReq) 
	{
		log.info("Inside ClientController / registerClient()");
		
		String response = null;
		
		if(log.isInfoEnabled())
		{
			log.info("Client registration request is : " + clientRegReq);
		}
       
		boolean isValidClient = clientCoreService.validateClient(clientRegReq);
		
		log.info("Is validClient : " + isValidClient);
		
		if(isValidClient)
			response = clientCoreService.registerClient(clientRegReq);
		else
			response = clientCoreService.generateErrResponse();
		
        
		return new ResponseEntity<String>(response,HttpStatus.CREATED);
	}
	
}
