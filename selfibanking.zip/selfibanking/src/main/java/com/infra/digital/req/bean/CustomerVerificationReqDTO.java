package com.infra.digital.req.bean;

import java.io.Serializable;

public class CustomerVerificationReqDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String clientId;
	private String apiKey;
	private CustomerVerificationDTO custData;

	public CustomerVerificationReqDTO() {
		super();
	}

	public CustomerVerificationReqDTO(String clientId, String apiKey,
			CustomerVerificationDTO custData) {
		super();
		this.clientId = clientId;
		this.apiKey = apiKey;
		this.custData = custData;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getApiKey() {
		return apiKey;
	}

	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	

	public CustomerVerificationDTO getCustData() {
		return custData;
	}

	public void setCustData(CustomerVerificationDTO custData) {
		this.custData = custData;
	}

	@Override
	public String toString() {
		return "CustomerVerificationReqBean [clientId=" + clientId + ", apiKey=" + apiKey
				+ ", custData=" + custData + "]";
	}

}
