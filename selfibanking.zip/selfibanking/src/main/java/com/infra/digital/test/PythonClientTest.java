/*package com.infra.digital.test;



import java.io.IOException;

import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

public class PythonClientTest {

	public static void pythonClient()
	{
		try {
			OkHttpClient client = new OkHttpClient();

			MediaType mediaType = MediaType.parse("multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
			RequestBody body = RequestBody.create(mediaType, "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"file\"; filename=\"deepika.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--");
			Request request = new Request.Builder()
			  .url("http://localhost:5002/facerekog/")
			  .post(body)
			  .addHeader("content-type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW")
			  .addHeader("cache-control", "no-cache")
			  .addHeader("postman-token", "b194ed98-a9f9-d25f-5e50-abf0b34080f0")
			  .build();

			Response response = client.newCall(request).execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		//return null;
	}
	
	public static void main(String[] args) {
		
		PythonClientTest.pythonClient();
	}
	
}


*/