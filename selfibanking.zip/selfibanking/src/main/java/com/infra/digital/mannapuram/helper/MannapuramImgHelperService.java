package com.infra.digital.mannapuram.helper;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import com.infra.digital.commons.ApplicationConstants;
import com.infra.digital.mannupuram.bean.Employee;

@Component
@PropertySource("classpath:mannapuram.properties")
@ConfigurationProperties
@EnableAsync
public class MannapuramImgHelperService {

	private Log log = LogFactory.getLog(this.getClass());

	@Value("${empLoginImgDir}")
	private String empLoginImgDir;

	@Value("${empTrainningImgDir}")
	private String empTrainningImgDir;

	@Value("${empImgDir}")
	private String empImgDir;

	public List<String> saveCustomerImage(Employee employee) {

		log.info("Inside MannapuramImgHelperService/empLoginImgDir()");

		List<String> empSelfieDataList = null;
		HashMap<String, Object> empDetailMap = null;
		List<String> imgUrlList = null;

		if (log.isInfoEnabled()) {
			log.info("empLoginImgDir : " + empLoginImgDir);
			log.info("empTrainningImgDir : " + empTrainningImgDir);
			log.info("customerRegBean : " + employee);
		}

		try {

			empSelfieDataList = new ArrayList<String>();

			empSelfieDataList.add(employee.getEmpImg());

			empDetailMap = new HashMap<String, Object>();
			empDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.IMG_LIST, empSelfieDataList);
			empDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID, employee.getClientId());

			imgUrlList = createImage(empDetailMap);

			log.info("imgUrlList : " + imgUrlList);

			if (null != imgUrlList) {
				return imgUrlList;
			} else {
				return imgUrlList;
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.info("Exception in saving customer image is : " + e.getMessage(), e.getCause());
			return imgUrlList;
		}

	}

	@SuppressWarnings("unchecked")
	private List<String> createImage(HashMap<String, Object> empDetailMap) {

		log.info("Inside MannapuramImgHelperService/createImage()");

		List<String> imgList = (ArrayList<String>) empDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.IMG_LIST);

		log.info("Img list is : " + imgList.size());

		String clientDir = null;
		String imgName = null;
		String filePath = null;
		List<String> imgUrlList = null;
		File empImg = null;

		try {

			imgUrlList = new ArrayList<String>();

			for (String img : imgList) {
				try {
					imgName = getImageName(empDetailMap);
					empDetailMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG, imgName);
					byte[] bytearray = Base64.getDecoder().decode(img.replaceAll("\n", ""));

					BufferedImage imag = ImageIO.read(new ByteArrayInputStream(bytearray));
					
					
					BufferedImage result = new BufferedImage(
							imag.getWidth(),
							imag.getHeight(),
		                    BufferedImage.TYPE_INT_RGB);

		            Graphics2D graphic = result.createGraphics();
		            graphic.drawImage(imag, 0, 0, Color.WHITE, null);

		            for (int i = 0; i < result.getHeight(); i++) {
		                for (int j = 0; j < result.getWidth(); j++) {
		                    Color c = new Color(result.getRGB(j, i));
		                    int red = (int) (c.getRed() * 0.299);
		                    int green = (int) (c.getGreen() * 0.587);
		                    int blue = (int) (c.getBlue() * 0.114);
		                    Color newColor = new Color(
		                            red + green + blue,
		                            red + green + blue,
		                            red + green + blue);
		                    result.setRGB(j, i, newColor.getRGB());
		                }
		            }

					
					

					empImg = new File(empLoginImgDir, imgName);
					log.info("employee Image : " + empImg.getAbsolutePath());
					ImageIO.write(result, ApplicationConstants.APP_KEY_CONSTANTS.JPG_IMG_EXTENSION, empImg);

					filePath = empImg.getAbsolutePath();
					imgUrlList.add(filePath);

				} catch (Exception e) {
					log.error("Exception in image writing : " + e.getMessage(), e.getCause());
					e.printStackTrace();
					return imgUrlList;
				}

				log.info("image save succesfully!!");
				return imgUrlList;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return imgUrlList;
		}

		return imgUrlList;
	}

	private String getImageName(HashMap<String, Object> customerDetailMap) {
		log.info("Inside MannapuramImgHelperService/getImageName()");

		StringBuilder custImgNameBuilder = new StringBuilder();
		custImgNameBuilder.append(customerDetailMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID));
		custImgNameBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME_SEPERATOR);
		custImgNameBuilder.append(String.valueOf(System.nanoTime()));
		custImgNameBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.FILE_EXTENSION_BUILDER);
		custImgNameBuilder.append(ApplicationConstants.APP_KEY_CONSTANTS.JPG_IMG_EXTENSION);

		return custImgNameBuilder.toString();
	}

	@Async
	public void saveEmpImg(HashMap<String, String> empImgDataMap) {

		log.info("Employee img data map is : " + empImgDataMap);
		
		String dir = isEmpDirExists(empImgDataMap);

		log.info("Directory is : " + dir);

		try {

			byte[] bytearray = Base64.getDecoder()
					.decode(empImgDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG).replaceAll("\n", ""));

			BufferedImage imag = ImageIO.read(new ByteArrayInputStream(bytearray));
			
			 BufferedImage result = new BufferedImage(
					 imag.getWidth(),
					 imag.getHeight(),
	                    BufferedImage.TYPE_INT_RGB);

	            Graphics2D graphic = result.createGraphics();
	            graphic.drawImage(imag, 0, 0, Color.WHITE, null);

	            for (int i = 0; i < result.getHeight(); i++) {
	                for (int j = 0; j < result.getWidth(); j++) {
	                    Color c = new Color(result.getRGB(j, i));
	                    int red = (int) (c.getRed() * 0.299);
	                    int green = (int) (c.getGreen() * 0.587);
	                    int blue = (int) (c.getBlue() * 0.114);
	                    Color newColor = new Color(
	                            red + green + blue,
	                            red + green + blue,
	                            red + green + blue);
	                    result.setRGB(j, i, newColor.getRGB());
	                }
	            }


			File imgName = new File(empImgDataMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_IMG_TO_BE_VERIFY));

			ImageIO.write(result, ApplicationConstants.APP_KEY_CONSTANTS.JPG_IMG_EXTENSION,
					new File(dir, imgName.getName()));
		} catch (Exception e) {
			log.error("Exception in image writing : " + e.getMessage(), e.getCause());
			e.printStackTrace();

		}
	}

	private String isEmpDirExists(HashMap<String, String> empImgDataMap) {
		File file = new File(empImgDir + empImgDataMap.get(ApplicationConstants.MANNAPURAM_APP_KEY_CONSTANTS.EMP_ID));

		if (!file.exists()) {

			if (file.mkdir()) {
				return file.getAbsolutePath();
			} else {
				return file.getAbsolutePath();
			}
		}

		return file.getAbsolutePath();

	}

}
