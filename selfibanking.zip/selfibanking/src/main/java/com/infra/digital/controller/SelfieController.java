package com.infra.digital.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.assertj.core.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.infra.digital.commons.ApplicationConstants;
import com.infra.digital.helper.CustomerHelperService;
import com.infra.digital.req.bean.CustomerPaymentDTO;
import com.infra.digital.req.bean.CustomerRegReqDTO;
import com.infra.digital.req.bean.CustomerVerificationReqDTO;
import com.infra.digital.service.ICustomerCoreService;

@RestController
@RequestMapping("/customer")
public class SelfieController {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICustomerCoreService customerCoreService;

	@Autowired
	private CustomerHelperService customerHelperService;

	@RequestMapping(value = "/payment/registration", method = RequestMethod.GET)
	public ResponseEntity<String> listAllUsers() {
		log.info("inside SelfieController/listAllUsers() ");

		return new ResponseEntity<String>(HttpStatus.OK);
	}

	/*
	 * @date 18052018
	 * 
	 * @author Raman Gupta
	 * 
	 * @Method validateCustomer
	 * 
	 * @discription validating customer in SelfieBanking system against his/her
	 * mobile no and mPin
	 */

	@RequestMapping(value = "/payment/login", method = RequestMethod.POST)
	public ResponseEntity<String> validateCustomer(@RequestBody CustomerRegReqDTO req) {

		log.info("Inside SelfieController / validateCustomer()");

		boolean isValidClient = false;
		String response = null;
		HashMap<String, String> verifyClientDataMap = null;

		if (log.isInfoEnabled()) {
			log.info("Customer register request is : " + req);
		}

		verifyClientDataMap = getVerifyDataMap(req.getApiKey(), req.getClientId());

		isValidClient = customerCoreService.validateClient(verifyClientDataMap);

		if (isValidClient) {
			try {
				response = customerCoreService.validateCustomer(req);
				return new ResponseEntity<String>(response, HttpStatus.CREATED);
			} catch (Exception e) {
				log.error("Exception in valdate customer : " + e.getMessage(), e.getCause());
				e.printStackTrace();
				response = customerCoreService.generateErrResponse(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG);
				return new ResponseEntity<String>(response, HttpStatus.OK);
			}

		} else {
			response = customerCoreService.generateErrResponse(ApplicationConstants.APP_MESSAGES.UNAUTH_CLIENT_MSG);
			return new ResponseEntity<String>(response, HttpStatus.OK);
		}

	}

	/*
	 * @date 18052018
	 * 
	 * @author Raman Gupta
	 * 
	 * @Method registerCustomer
	 * 
	 * @discription register customer in selfie banking system
	 * 
	 */

	@RequestMapping(value = "/payment/registration", method = RequestMethod.POST)
	public ResponseEntity<String> registerCustomer(@RequestBody CustomerRegReqDTO req) {
		log.info("Inside SelfieController / registerCustomer()");

		if (log.isInfoEnabled()) {
			log.info("Customer register customer request is : " + req);
		}

		boolean isValidClient = false;
		String response = null;
		HashMap<String, String> verifyClientDataMap = null;

		if (log.isInfoEnabled()) {
			log.info("Customer register request is : " + req);
		}

		verifyClientDataMap = getVerifyDataMap(req.getApiKey(), req.getClientId());

		isValidClient = customerCoreService.validateClient(verifyClientDataMap);

		if (isValidClient) {
			try {
				response = customerCoreService.registerCustomer(req);
				return new ResponseEntity<String>(response, HttpStatus.CREATED);
			} catch (IOException e) {
				log.error("IOException in register customer : " + e.getMessage(), e.getCause());
				e.printStackTrace();
				response = customerCoreService.generateErrResponse(ApplicationConstants.APP_MESSAGES.GENERIC_ERR_MSG);
				return new ResponseEntity<String>(response, HttpStatus.OK);
			}

		} else {
			response = customerCoreService.generateErrResponse(ApplicationConstants.APP_MESSAGES.UNAUTH_CLIENT_MSG);
			return new ResponseEntity<String>(response, HttpStatus.OK);
		}
	}

	private HashMap<String, String> getVerifyDataMap(String apiKey, String clientId) {
		HashMap<String, String> verifyDataMap = new HashMap<String, String>();
		verifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID, clientId);
		verifyDataMap.put(ApplicationConstants.APP_KEY_CONSTANTS.API_KEY, apiKey);

		return verifyDataMap;

	}

	/*
	 * @date 18052018
	 * 
	 * @author Raman Gupta
	 * 
	 * @Method verifyCustomer
	 * 
	 * @discription Verifying customers against his/her facial landmarks
	 * 
	 */

	@RequestMapping(value = "/payment/verification", method = RequestMethod.POST)
	public ResponseEntity<String> verifyCustomer(@RequestBody CustomerVerificationReqDTO req) {

		log.info("Inside SelfieController / verifyCustomer()");

		boolean isValidClient = false;
		String response = null;
		HashMap<String, String> verifyClientDataMap = null;

		if (log.isInfoEnabled()) {
			log.info("Customer verification request is : " + req);
		}

		verifyClientDataMap = getVerifyDataMap(req.getApiKey(), req.getClientId());

		/*
		 * Check whether client registered or not
		 */
		isValidClient = customerCoreService.validateClient(verifyClientDataMap);

		if (isValidClient) {
			response = customerCoreService.verifyCustomer(req);
		} else {
			response = customerCoreService.generateErrResponse(ApplicationConstants.APP_MESSAGES.UNAUTH_CLIENT_MSG);
			return new ResponseEntity<String>(response, HttpStatus.OK);
		}

		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	/*
	 * @date 18052018
	 * 
	 * @author Raman Gupta
	 * 
	 * @Method fundDetails
	 * 
	 * @Demo
	 * 
	 * @discription NA
	 * 
	 */

	@RequestMapping(value = "/payment/funddetails", method = RequestMethod.POST)
	public ResponseEntity<String> fundDetails(@RequestBody CustomerRegReqDTO req) {

		log.info("Inside SelfieController / fundDetails()");

		if (log.isInfoEnabled()) {
			log.info("Customer fundDetails request is : " + req);
		}

		return new ResponseEntity<String>(customerCoreService.fetchFundDetails(req), HttpStatus.OK);
	}

	/*
	 * @date 24052018
	 * 
	 * @author Raman Gupta
	 * 
	 * @Method fundDetails
	 * 
	 * @Demo
	 * 
	 * @discription NA
	 * 
	 */

	@RequestMapping(value = "/payment/facedetect", method = RequestMethod.POST)
	public ResponseEntity<String> faceDetect(@RequestBody CustomerVerificationReqDTO req) {

		log.info("Inside SelfieController / faceDetect()");

		if (log.isInfoEnabled()) {
			log.info("Customer faceDetect request is : " + req);
		}

		String response = null;
		HashMap<String, String> verifyClientDataMap = null;
		boolean isValidClient = false;

		if (log.isInfoEnabled()) {
			log.info("Customer facedetect request is : " + req);
		}

		verifyClientDataMap = getVerifyDataMap(req.getApiKey(), req.getClientId());

		isValidClient = customerCoreService.validateClient(verifyClientDataMap);

		if (isValidClient) {
			response = customerCoreService.extractFace(req);
		}

		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/payment/validatetrxn", method = RequestMethod.POST)
	public ResponseEntity<String> validateTransaction(@RequestBody CustomerPaymentDTO req) {

		log.info("Inside SelfieController / validateTransaction()");

		String response = null;
		HashMap<String, String> verifyClientDataMap = null;
		boolean isValidClient = false;

		if (log.isInfoEnabled()) {
			log.info("Customer validateTransaction request is : " + req);
		}

		verifyClientDataMap = getVerifyDataMap(req.getApiKey(), req.getClientId());

		isValidClient = customerCoreService.validateClient(verifyClientDataMap);

		if (isValidClient)

		{
			response = customerCoreService.validateTrxnAmt(req);

			log.info("response is : " + response);

		}

		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/payment/blinkDetection1", method = RequestMethod.POST, consumes = {
			"multipart/form-data" })
	public ResponseEntity<String> blinkDetection1(@RequestPart("file") MultipartFile file) {

		log.info("Inside SelfieController / blinkDetection()");

		log.info("File name : " + file.getOriginalFilename());

		String fileName = null;
		String response = null;
		String filePath = null;
		String uploadedFileLocation = null;

		HashMap<String, String> blinkDetectParamsMap = null;

		try {

			/*
			 * fileName = file.getOriginalFilename(); filePath =
			 * customerHelperService.writeFile(file);
			 */

			uploadedFileLocation = "E://uploaded//" + file.getOriginalFilename();
			filePath = writeToFile(file.getInputStream(), uploadedFileLocation);

			log.info("File path is : " + filePath);

			if (null != filePath) {
				blinkDetectParamsMap = new HashMap<String, String>();
				blinkDetectParamsMap.put(ApplicationConstants.APP_KEY_CONSTANTS.FILE_PATH, filePath);
				blinkDetectParamsMap.put("filename", file.getName());
				response = customerCoreService.detectBlink(blinkDetectParamsMap);
				customerCoreService.deleteBlinkVideo(blinkDetectParamsMap);

				log.info("response is : " + response);
			}

		} catch (IllegalStateException e) { // TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) { // TODO Auto-generated catch block
			e.printStackTrace();
		}

		return new ResponseEntity<String>(response, HttpStatus.OK);

	}

	private String writeToFile(InputStream inputStream, String uploadedFileLocation) {

		OutputStream out = null;
		try {
			out = new FileOutputStream(new File(uploadedFileLocation));
			int read = 0;
			byte[] bytes = new byte[1024];

			out = new FileOutputStream(new File(uploadedFileLocation));
			while ((read = inputStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			out.flush();
			out.close();
		} catch (IOException e) {
			log.error("IOException in SelfieController/writeToFile()");
			e.printStackTrace();
			return null;

		} catch (Exception e) {
			log.error("Exception in SelfieController/writeToFile()");
			e.printStackTrace();
			return null;

		} finally {
			try {
				if (null != out)
					out.close();
			} catch (IOException e) {
				log.error("Exception in closing stream SelfieController/writeToFile()");
				e.printStackTrace();
				return null;

			}

		}

		return uploadedFileLocation;

	}

	@RequestMapping(value = "/payment/blinkDetection", method = RequestMethod.POST, consumes = {
			"multipart/form-data" })
	public ResponseEntity<String> blinkDetection(@RequestPart("file") MultipartFile file) {

		log.info("Inside SelfieController / blinkDetection()");

		log.info("File name : " + file.getOriginalFilename());

		String fileName = null;
		String response = null;
		String orignalFilePath = null;
		String uploadedFileLocation = null;

		HashMap<String, String> blinkDetectParamsMap = null;

		try {

			/*
			 * fileName = file.getOriginalFilename(); filePath =
			 * customerHelperService.writeFile(file);
			 */

			HashMap<String, String> customerInfoMap = getCustomerInfo(file.getOriginalFilename());

			log.info("getCustomerInfoMap : " + customerInfoMap);

			uploadedFileLocation = getBuildFileLocation(customerInfoMap);

			String absolutePath = checkUploadFileLocation(uploadedFileLocation);

			log.info("uploadedFileLocation : " + absolutePath);

			customerInfoMap.put(ApplicationConstants.APP_KEY_CONSTANTS.FILE_UPLOAD_LOCATION, absolutePath);

			orignalFilePath = writeToFile(file.getInputStream(), uploadedFileLocation + file.getOriginalFilename());

			log.info("File path is : " + orignalFilePath);

			if (null != orignalFilePath) {
				customerInfoMap.put(ApplicationConstants.APP_KEY_CONSTANTS.FILE_PATH, orignalFilePath);
				/*
				 * blinkDetectParamsMap = new HashMap<String, String>();
				 * blinkDetectParamsMap.put(ApplicationConstants.APP_KEY_CONSTANTS.FILE_PATH,
				 * orignalFilePath); blinkDetectParamsMap.put("filename",
				 * file.getOriginalFilename());
				 */
				response = customerCoreService.detectBlink(customerInfoMap);

				// * Delete Customer vedio

				 customerCoreService.deleteBlinkVideo(customerInfoMap);

				log.info("response is : " + response);
			}

		} catch (IllegalStateException e) {
			log.error("IllegalStateException inside SelfieController / blinkDetection() : " + e.getMessage(),
					e.getCause());
			e.printStackTrace();
		} catch (Exception e) {
			log.error("Exception inside SelfieController / blinkDetection() : " + e.getMessage(), e.getCause());
			e.printStackTrace();
		}

		return new ResponseEntity<String>(response, HttpStatus.OK);

	}

	private String checkUploadFileLocation(String uploadedFileLocation) {
		File file = new File(uploadedFileLocation);

		if (!file.exists()) {
			if (file.mkdir()) {
				return file.getAbsolutePath();
			} else {
				return file.getAbsolutePath();
			}
		}

		return file.getAbsolutePath();
	}

	private String getBuildFileLocation(HashMap<String, String> getCustomerInfoMap) {
		StringBuilder uploadLocationBuilder = new StringBuilder();
		uploadLocationBuilder.append("E:\\INFRA_RND\\selfiebanking\\blinkdetection\\");
		uploadLocationBuilder.append(getCustomerInfoMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID));
		uploadLocationBuilder.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		uploadLocationBuilder.append(getCustomerInfoMap.get(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID));
		uploadLocationBuilder.append(ApplicationConstants.APP_VALUE_CONSTANTS.FILE_PATH_SEPERATOR);
		// uploadLocationBuilder.append(getCustomerInfoMap.get(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME));

		return uploadLocationBuilder.toString();

	}

	private HashMap<String, String> getCustomerInfo(String originalFilename) {
		log.info("Inside SelfieController/getCustomerInfo() ");

		HashMap<String, String> custInfoMap = new HashMap<String, String>();

		String[] custInfo = originalFilename.split(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME_SPLITTER);
		custInfoMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CLIENT_ID, custInfo[0]);
		custInfoMap.put(ApplicationConstants.APP_KEY_CONSTANTS.CUST_ID, custInfo[1]);
		custInfoMap.put(ApplicationConstants.APP_KEY_CONSTANTS.FILE_NAME, custInfo[2]);

		return custInfoMap;

	}

}
