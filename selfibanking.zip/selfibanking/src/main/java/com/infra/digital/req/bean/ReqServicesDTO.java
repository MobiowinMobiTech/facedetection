package com.infra.digital.req.bean;

import java.io.Serializable;

public class ReqServicesDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String isAuthService;
	private String isTransactionService;
	
	
	public ReqServicesDTO() {
		super();
	}


	public ReqServicesDTO(String isAuthService, String isTransactionService) {
		super();
		this.isAuthService = isAuthService;
		this.isTransactionService = isTransactionService;
	}


	@Override
	public String toString() {
		return "ReqServices [isAuthService=" + isAuthService + ", isTransactionService=" + isTransactionService + "]";
	}
	
	
}
