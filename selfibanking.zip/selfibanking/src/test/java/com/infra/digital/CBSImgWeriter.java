package com.infra.digital;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Iterator;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

public class CBSImgWeriter {

	public static void main(String[] args) {
		writeImg();
	}

	private static void writeImg() {
		
		try {
			Image img = ImageIO.read(new File("D:\\INFRA_RND\\120418\\test2.jpg"));
			BufferedImage bImage = new BufferedImage(300, 400, BufferedImage.TYPE_INT_RGB);
			Graphics bg = bImage.getGraphics();
			bg.drawImage(img, 300,400, null);
			ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();
			
			Iterator iter = ImageIO.getImageWritersByFormatName("jpeg");
			ImageWriter writer = (ImageWriter)iter.next();
			ImageWriteParam param = writer.getDefaultWriteParam();
			param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
			//param.setCompressionQuality(quality);
			ImageOutputStream outputStream = ImageIO.createImageOutputStream(arrayOutputStream);
			System.out.println("outputStream : "  + outputStream);
			writer.setOutput(outputStream);
			outputStream.flush();
			IIOImage iioImage = new IIOImage(bImage, null,null);
			writer.write(null, iioImage, param);
			writer.dispose();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
}
