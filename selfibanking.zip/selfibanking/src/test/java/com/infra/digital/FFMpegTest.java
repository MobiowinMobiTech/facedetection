package com.infra.digital;

import java.io.IOException;

import net.bramp.ffmpeg.FFmpeg;
import net.bramp.ffmpeg.FFmpegExecutor;
import net.bramp.ffmpeg.FFprobe;
import net.bramp.ffmpeg.builder.FFmpegBuilder;

public class FFMpegTest {

	public static void main(String[] args) {

		try {
			FFmpeg ffmpeg = new FFmpeg("E:\\ffmeg\\ffmpeg\\bin\\ffmpeg.exe");
			FFprobe ffprobe = new FFprobe("E:\\ffmeg\\ffmpeg\\bin\\ffprobe.exe");

			FFmpegBuilder builder = new FFmpegBuilder()

					.setInput("E:\\INFRA_RND\\selfiebanking\\blinkdetection\\HDFCXXX121\\476504147659603\\HDFCXXX121_476504147659603_1533123165583.mp4") // Filename, or a FFmpegProbeResult
					.overrideOutputFiles(true) // Override the output if it exists

					.addOutput("E:\\INFRA_RND\\selfiebanking\\blinkdetection\\HDFCXXX121\\476504147659603\\HDFCXXX121_476504147659603_1533123165583.avi") // Filename for the destination
					.setFormat("avi") // Format is inferred from filename, or can be set
					//.setTargetSize(250_000) // Aim for a 250KB file

					.disableSubtitle() // No subtiles

					/*.setAudioChannels(1) // Mono audio
					.setAudioCodec("aac") // using the aac codec
					.setAudioSampleRate(48_000) // at 48KHz
					.setAudioBitRate(32768) // at 32 kbit/s
*/
					.setVideoCodec("libx264") // Video using x264 *'XVID'
					.setVideoFrameRate(24, 1) // at 24 frames per second
					.setVideoResolution(640, 480) // at 640x480 resolution

					.setStrict(FFmpegBuilder.Strict.EXPERIMENTAL) // Allow FFmpeg to use experimental specs
					.done();
			
			FFmpegExecutor executor = new FFmpegExecutor(ffmpeg, ffprobe);

			// Run a one-pass encode
			executor.createJob(builder).run();

			// Or run a two-pass encode (which is better quality at the cost of being slower)
			//executor.createTwoPassJob(builder).run();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
