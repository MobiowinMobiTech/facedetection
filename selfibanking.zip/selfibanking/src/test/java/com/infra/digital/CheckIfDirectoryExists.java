package com.infra.digital;

import java.io.File;

public class CheckIfDirectoryExists {

	
public static void main(String[] args) {
		
		File dir = new File("D:\\INFRA_RND\\selfiebanking");
		
		// Tests whether the directory denoted by this abstract pathname exists.
		boolean exists = dir.exists();
		 
		System.out.println("Directory " + dir.getPath() + " exists: " + exists);	
	}
}
