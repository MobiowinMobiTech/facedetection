from PIL import Image
import numpy as np

pil_im = Image.open('E:\\INFRA_RND\\120418\\testImg\\anup\\your_file_2018-06-19_10_55_27.jpg')
pil_imgray = pil_im.convert('L')
pil_imgray.save("E:\\INFRA_RND\\120418\\testImg\\anup\\your_file_2018-06-19_10_55_28.jpg")

#img = np.array(list(pil_imgray.getdata(band=0)), float)
#img.shape = (pil_imgray.size[1], pil_imgray.size[0])
#img.imshow(img)