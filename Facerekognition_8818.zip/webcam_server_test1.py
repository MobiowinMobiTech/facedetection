import cv2
import requests
import numpy as np

r = requests.get('http://localhost:5004/video_feed/', stream=True)
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('D://output1.avi',fourcc, 14.0, (640,480))
if(r.status_code == 200):
    bytes = bytes()
    for chunk in r.iter_content(chunk_size=1024):
        bytes += chunk
        a = bytes.find(b'\xff\xd8')
        b = bytes.find(b'\xff\xd9')
        if a != -1 and b != -1:
            jpg = bytes[a:b+2]
            bytes = bytes[b+2:]
            i = cv2.imdecode(np.fromstring(jpg, dtype=np.uint8), cv2.IMREAD_COLOR)
            #cv2.imshow('videofeed_localhost', i)
            out.write(i)
            if cv2.waitKey(1) == 27:
                exit(0)
else:
    print("Received unexpected status code {}".format(r.status_code))