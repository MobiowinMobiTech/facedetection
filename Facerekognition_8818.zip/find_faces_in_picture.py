from PIL import Image
import face_recognition
import PIL.Image
import json
import base64
import time
import os
from os.path import basename
from flask import Flask, jsonify, request, redirect

size = 300, 400
app = Flask(__name__)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

global grey_face_dir
grey_face_dir = ''


global customerId
customerId=''

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/faceextract/', methods=['GET', 'POST'])
def upload_image():
    # Check if a valid image file was uploaded
    global grey_face_dir
    global customerId
    if request.method == 'POST':
        if 'custimgtobeextract' not in request.files:
            return redirect(request.url)

        file = request.files['custimgtobeextract']
        grey_face_dir = request.form['greyfacedir']
        customerId = request.form['customerId']
        if file.filename == '':
            return redirect(request.url)

        if file and allowed_file(file.filename):
            # The image file seems valid! Detect faces and return the result.
            return detect_faces_in_image(file)

    # If no valid image file was uploaded, show the file upload form:
    return'''
    
    <!doctype html>
    <title>Face Dectector</title>--
    <h1>Upload a picture to Detect faces</h1>
    <form method="POST" enctype="multipart/form-data">
      <input type="file" name="custimgtobeextract">
      <input type="text" name="greyfacedir" />
      <input type="text" name="customerId" />
      <input type="submit" value="Upload">
    </form>
    '''

responseDict = {}
imgData = {}

def detect_faces_in_image(image):
    #i=0
    global grey_face_dir
    global customerId
    
    print("inside detect_faces_in_image",image)
    img = face_recognition.load_image_file(image)
    face_locations = face_recognition.face_locations(img)

    print("I found {} face(s) in this photograph.".format(len(face_locations)))
    print("no of faces in pic : ",format(len(face_locations)))
    
    if int(format(len(face_locations))) > 1:
        responseDict["status"] = "02"
        responseDict["message"] = "Picture has more the one faces"
        imgData['facecount'] = format(len(face_locations))
        responseDict["data"] = imgData
        return jsonify(responseDict)
        
    
    if int(format(len(face_locations))) < 1:
        responseDict["status"] = "01"
        responseDict["message"] = "No Face Found"
        imgData['facecount'] = format(len(face_locations))
        responseDict["data"] = imgData
        return jsonify(responseDict)   

    for face_location in face_locations:
    # Print the location of each face in this image
        top, right, bottom, left = face_location
        print("A face is located at pixel location Top: {}, Left: {}, Bottom: {}, Right: {}".format(top, left, bottom, right))
        #face_image = img[top:bottom, left:right]
        pil_image = PIL.Image.fromarray(img)
        #pil_image = img.fromarray(face_image)
        pil_image.thumbnail(size, Image.ANTIALIAS)
        timecode = time.strftime("%Y-%m-%d_%H_%M_%S", time.gmtime())
        #img_path = "E:\\INFRA_RND\\120418\\testImg\\anup\\your_file_"+timecode+".jpg"
        img_path = grey_face_dir+customerId+"_"+timecode+".jpg"
        pil_image.save(img_path)
        pil_grey_img = Image.open(img_path).convert('L')
        pil_grey_img.save(img_path)
        #pil_grey_img.show()
        
        #with open(img_path, "rb") as imageFile:
        #    str = base64.b64encode(imageFile.read())
        #    print("byte array image is : ",str)
        #    print(os.path.basename(img_path))

        #pil_image.save(face_image)
        #face_image.save("D:\\INFRA_RND\\120418\\testImg\\aadhar1.jpg")
        #pil_image.show()
        #i+=1
        #imgData['name'] = "raman"
        
        responseDict["status"] = "00"
        responseDict["message"] = "Face Found"
        imgData["imgpath"] = img_path
        imgData['facecount'] = format(len(face_locations))
        #imgData['image'] = str
        responseDict["data"] = imgData    
    return jsonify(responseDict)
    

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5015)