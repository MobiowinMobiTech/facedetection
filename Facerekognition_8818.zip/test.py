import face_recognition
import click
import os
from os.path import basename
from flask import Flask, jsonify, request, redirect
import json
# import re
# import face_recognition.api as face_recognition
# import multiprocessing
# import itertools
# import sys
import PIL.Image
import numpy as np
import glob

known_people_folder = "D:\\INFRA_RND\\120418\\testImg\\*"
def image_files_in_folder(folder):
    return [os.path.join(folder, f) for f in os.listdir(folder) ]

def print_result(filename, name, distance, show_distance=False):
    if show_distance:
        print("{},{},{}".format(filename, name, distance))
    else:
        print("{},{}".format(filename, name))
def scan_known_people(known_people_folder):
    print("inside scan_known_people")
    known_names = []
    known_face_encodings = []

    print("known_people_folder",known_people_folder)
    for file1 in glob.glob(known_people_folder):
        basename = os.path.splitext(os.path.basename(file1))[0]
        #print (file1)
        img = face_recognition.load_image_file(file1)
        try:
            encodings = face_recognition.face_encodings(img)
            #print(encodings)
        except:
            print ("###################",file1)

        if len(encodings) > 1:
            click.echo("WARNING: More than one face found in {}. Only considering the first face.".format(file1))
           

        if len(encodings) == 0:
            click.echo("WARNING: No faces found in {}. Ignoring file.".format(file1))

        else:
            known_names.append(basename)
            known_face_encodings.append(encodings[0])
    
    return known_names,known_face_encodings


def detect_faces_in_image(file_stream="D:\\INFRA_RND\\tranning\\test1Snipped0.jpg"):
    #file_stream = file_stream1
    #print("********************************",basename(file_stream))
    known_names, known_face_encodings = scan_known_people(known_people_folder)
    print("known_names : ",known_names)
    print("length",len(known_face_encodings))
    #print("known_face_encodings : ",known_face_encodings)
    # Load the uploaded image file
    #img = face_recognition.load_image_file(file_stream)
    # Get face encodings for any faces in the uploaded image
    #print("known names and face encoding done")
    #print("<-------2----------->",file_stream.shape)
#     if max(file_stream.shape) > 1600:
#         pil_img = PIL.Image.fromarray(file_stream)
#         pil_img.thumbnail((1600, 1600), PIL.Image.LANCZOS)
#         file_stream = np.array(pil_img)

    # Load the uploaded image file
    img = face_recognition.load_image_file(file_stream)
    # Get face encodings for any faces in the uploaded image
    unknown_face_encodings = face_recognition.face_encodings(img)
    
#     unknown_face_encodings = face_recognition.load_image_file(file_stream)

    #print("unknown face encoding done",unknown_face_encodings)

#     tolerance=0.1,
    show_distance=False
    #face_found = is_obama = False
    dict1 = {}
    
    for i in range(3):
        list1 = []
#         print("============================")
#         print("len",len(unknown_face_encodings))
        if len(unknown_face_encodings) > 0:
            
            face_found = True
#             # See if the first face in the uploaded image matches the known face of Obama
            distances = face_recognition.face_distance(known_face_encodings[i], unknown_face_encodings)
#             print (distances)
            match_results = face_recognition.compare_faces([known_face_encodings[i]], unknown_face_encodings[0],tolerance=0.1)
            if not match_results[0]:
                is_obama = True
                #print(is_obama)
           
        
                distances = float(distances[0])
                
                list1.append(distances)
                list1.append(face_found)
                #print(list1)
                str1 = "img"+str(i)
                dict1[str1] = list1
          
    if not unknown_face_encodings:
        # print out fact that no faces were found in image
        print_result(file_stream, "no_persons_found", None, show_distance)
            
    
    return json.dumps(dict1)        


print (detect_faces_in_image())