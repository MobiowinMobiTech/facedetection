import cv2
from flask import Flask, render_template
import turtle
import win32api
import logging
import coloredlogs
import winsound

app = Flask(__name__)
logger = logging.getLogger(__name__)
coloredlogs.install(level='DEBUG')
#cap = cv2.VideoCapture(0)
face_cascade = cv2.CascadeClassifier('D:\INFRA_RND\open cv data\opencv-master\opencv-master\data\haarcascades\haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier('D:\INFRA_RND\open cv data\opencv-master\opencv-master\data\haarcascades\haarcascade_eye.xml')


@app.route('/')
def index():
    return render_template('index.html')


def detect_faces_in_image(image):
    print("inside detect_faces_in_image",image)
    _,f=image.read()
    gray = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    return faces
    # type(faces)
    
    #if len(faces) == 0:
    #    print("No faces found")

        
@app.route('/video_feed/', methods=['GET', 'POST'])
def main():
    cap = cv2.VideoCapture(0)
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter('D://output1.avi',fourcc, 20.0, (640,480))
    while(cap.isOpened()):
        ret, frame = cap.read()
        if ret==True:
            frame = cv2.flip(frame,1)
            #facecount = detect_faces_in_image(cap)
            if len(detect_faces_in_image(cap)) < 1:
                print("No face found....tale some action")
                draw = turtle.Turtle()
                draw.speed(1)
                draw.pencolor("blue")
                logger.warning('sit straight and focus on screen.')
                duration = 100  # millisecond
                freq = 440  # Hz
                #winsound.Beep(freq, duration)
                #win32api.MessageBox(0, 'Sit straight and focus on screen.', 'Warning', 0x00001000) 
            out.write(frame)
            #cv2.imshow('frame',frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        else:
            break


    cap.release()
    out.release()
    cv2.destroyAllWindows()
            


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5004, debug=True)