import http.client

conn = http.client.HTTPConnection("localhost:5002")

payload = "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"file\"; filename=\"deepika.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--"

headers = {
    'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
    'cache-control': "no-cache",
    'postman-token': "4b2ddd71-fa23-e2f7-ec55-604b8990feb9"
    }

conn.request("POST", "/facerekog/", payload, headers)

res = conn.getresponse()
data = res.read()