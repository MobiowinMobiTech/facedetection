from PIL import Image
import face_recognition
import PIL.Image
import json
import base64
import time
import os
from os.path import basename
from flask import Flask, jsonify, request, redirect

size = 250, 250
app = Flask(__name__)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
# Load the jpg file into a numpy array
image = face_recognition.load_image_file("D:\\INFRA_RND\\120418\\testImg\\download.jpg")

# Find all the faces in the image using the default HOG-based model.
# This method is fairly accurate, but not as accurate as the CNN model and not GPU accelerated.
# See also: find_faces_in_picture_cnn.py

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/faceextract/', methods=['GET', 'POST'])
def upload_image():
    # Check if a valid image file was uploaded
    global known_people_folder
    if request.method == 'POST':
        if 'custimgtobeverify' not in request.files:
            return redirect(request.url)

        file = request.files['custimgtobeverify']

        if file.filename == '':
            return redirect(request.url)

        if file and allowed_file(file.filename):
            # The image file seems valid! Detect faces and return the result.
            return detect_faces_in_image(file)

    # If no valid image file was uploaded, show the file upload form:
    return '''
    
    <!doctype html>
    <title>Is this a picture of Obama?</title>
    <h1>Upload a picture to extract faces</h1>
    <form method="POST" enctype="multipart/form-data">
      <input type="file" name="custimgtobeverify">
      <input type="submit" value="Upload">
    </form>
    '''

responseDict = {}

def detect_faces_in_image(image):
    #i=0
    print("inside detect_faces_in_image",image)
    img = face_recognition.load_image_file(image)
    face_locations = face_recognition.face_locations(img)

    print("I found {} face(s) in this photograph.".format(len(face_locations)))
    print("no of faces in pic : ",format(len(face_locations)))
    
    if int(format(len(face_locations))) > 1:
        responseDict["status"] = "Picture has more the one faces"
        return jsonify(responseDict)
        

    for face_location in face_locations:
    # Print the location of each face in this image
        top, right, bottom, left = face_location
        print("A face is located at pixel location Top: {}, Left: {}, Bottom: {}, Right: {}".format(top, left, bottom, right))
        face_image = img[top:bottom, left:right]
        pil_image = PIL.Image.fromarray(face_image)
        #pil_image = img.fromarray(face_image)
        pil_image.thumbnail(size, Image.ANTIALIAS)
        timecode = time.strftime("%Y-%m-%d_%H;%M;%S", time.gmtime())
        img_path = "D:\\INFRA_RND\\120418\\testImg\\your_file_"+timecode+".jpg"
        pil_image.save(img_path)
        with open(img_path, "rb") as imageFile:
            str = base64.b64encode(imageFile.read())
            print("byte array image is : ",str)
            print(os.path.basename(img_path))

        #pil_image.save(face_image)
        #face_image.save("D:\\INFRA_RND\\120418\\testImg\\aadhar1.jpg")
        #pil_image.show()
        #i+=1
        responseDict["status"] = "success"    
    return jsonify(responseDict)
    

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5010, debug=True)


