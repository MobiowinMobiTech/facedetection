import face_recognition
import click
import os
from os.path import basename
# import re
# import face_recognition.api as face_recognition
# import multiprocessing
# import itertools
# import sys
# import PIL.Image
# import numpy as np
import json
from flask import Flask, jsonify, request, redirect

# You can change this to any folder on your system
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
#known_people_folder = "D:\\INFRA_RND\\120418\\testImg"
#file_stream1="D:\\INFRA_RND\\120418\\testImg\\deepika.jpg"
global known_people_folder
known_people_folder = ''

app = Flask(__name__)


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/facerekog/', methods=['GET', 'POST'])
def upload_image():
    # Check if a valid image file was uploaded
    global known_people_folder
    if request.method == 'POST':
        if 'custimgtobeverify' not in request.files:
            return redirect(request.url)

        file = request.files['custimgtobeverify']
        known_people_folder = request.form['knownfacedir']
        
        print(known_people_folder)

        if file.filename == '':
            return redirect(request.url)

        if file and allowed_file(file.filename):
            # The image file seems valid! Detect faces and return the result.
            return detect_faces_in_image(file)

    # If no valid image file was uploaded, show the file upload form:
    return '''

    <!doctype html>
    <title>Is this a picture of Obama?</title>
    <h1>Upload a picture and see if it's a picture of Raman!</h1>
    <form method="POST" enctype="multipart/form-data"></br>
      <input type="file" name="custimgtobeverify">
      <input type="text" id="knownfacedir" name="knownfacedir" />
      <input type="submit" value="Upload">
    </form>
    '''

def detect_faces_in_image(file_stream):
    global known_people_folder
    #file_stream = file_stream1
    #print("********************************",basename(file_stream))
    known_names, known_face_encodings = scan_known_people(known_people_folder)
    print("known_names : ",known_names)
    print("length",len(known_face_encodings))
    #print("known_face_encodings : ",known_face_encodings)
    # Load the uploaded image file
    #img = face_recognition.load_image_file(file_stream)
    # Get face encodings for any faces in the uploaded image
    #print("known names and face encoding done")
    #print("<-------2----------->",file_stream.shape)
#     if max(file_stream.shape) > 1600:
#         pil_img = PIL.Image.fromarray(file_stream)
#         pil_img.thumbnail((1600, 1600), PIL.Image.LANCZOS)
#         file_stream = np.array(pil_img)

    # Load the uploaded image file
    img = face_recognition.load_image_file(file_stream)
    # Get face encodings for any faces in the uploaded image
    unknown_face_encodings = face_recognition.face_encodings(img)
    
#     unknown_face_encodings = face_recognition.load_image_file(file_stream)

    #print("unknown face encoding done",unknown_face_encodings)

#     tolerance=0.1,
    show_distance=False
    #face_found = is_obama = False
    dict1 = {}
    resList = []
    #responseDict = {}
    i =0
    #for i in range(3):
    for known_encoding in known_face_encodings:
        list1 = []
        responseDict = {}
        print("============================")
#         print("len",len(unknown_face_encodings))
        if len(unknown_face_encodings) > 0:
            
            face_found = True
#             # See if the first face in the uploaded image matches the known face of Obama
            distances = face_recognition.face_distance(known_encoding, unknown_face_encodings)
#             print (distances)
            match_results = face_recognition.compare_faces([known_encoding], unknown_face_encodings[0],tolerance=0.5)
            if match_results[0]:
                #is_obama = True
                #print(is_obama)
           
        
                distances = float(distances[0])
                
                list1.append(distances)
                list1.append(face_found)
                
                responseDict["distance"] = distances
                responseDict["ismatch"] = face_found
                #list.append(object)
                print(responseDict)
                
                resList.append(responseDict)
                
                print(resList)
                
                #str1 = "img"+str(i)
    dict1["response"] = resList
                #i+=1
          
    if not unknown_face_encodings:
        # print out fact that no faces were found in image
        print_result(file_stream, "no_persons_found", None, show_distance)
            
    
    return jsonify(dict1)

    

def image_files_in_folder(folder):
    return [os.path.join(folder, f) for f in os.listdir(folder) ]

def print_result(filename, name, distance, show_distance=False):
    if show_distance:
        print("{},{},{}".format(filename, name, distance))
    else:
        print("{},{}".format(filename, name))

def scan_known_people(known_people_folder):
    print("inside scan_known_people")
    known_names = []
    known_face_encodings = []

    print("known_people_folder",known_people_folder)
    for file in image_files_in_folder(known_people_folder):
        basename = os.path.splitext(os.path.basename(file))[0]
        img = face_recognition.load_image_file(file)
        try:
            encodings = face_recognition.face_encodings(img)
            #print(encodings)
        except:
            print ("###################",file)

        if len(encodings) > 1:
            click.echo("WARNING: More than one face found in {}. Only considering the first face.".format(file))
           

        if len(encodings) == 0:
            click.echo("WARNING: No faces found in {}. Ignoring file.".format(file))

        else:
            known_names.append(basename)
            known_face_encodings.append(encodings[0])
    
    return known_names,known_face_encodings


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5010, debug=True)